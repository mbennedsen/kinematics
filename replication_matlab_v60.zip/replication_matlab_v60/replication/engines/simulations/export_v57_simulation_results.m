function zipFile=export_v57_simulation_results(nArrays)
% Make a compact, auditable return ZIP. Originals and restart files are retained.
if nargin<1,nArrays=12;end
[root,~,~,S]=prepare_v57_simulations;
collect_v57_simulations(nArrays);
files={'SHA256SUMS.tsv','Source_Provenance.json','README.txt'};
for folder={'src','inputs','summary','migration'}
 F=dir(fullfile(root,folder{1},'*'));for k=1:numel(F),if ~F(k).isdir,files{end+1}=fullfile(folder{1},F(k).name);end,end %#ok<AGROW>
end
F=dir(fullfile(root,'*.m'));for k=1:numel(F),files{end+1}=F(k).name;end %#ok<AGROW>
F=dir(fullfile(S.accuracyDir,'job_*.mat'));[~,aname]=fileparts(S.accuracyDir);
for k=1:numel(F),files{end+1}=fullfile(aname,F(k).name);end %#ok<AGROW>
[~,cname]=fileparts(S.coverageDir);
for r=1:S.coverageR
 rel=fullfile(cname,sprintf('rep_%04d',r));folder=fullfile(root,rel);ssComplete=false;
 f=fullfile(folder,'Results.mat');
 if isfile(f),L=load(f,'R');ssComplete=L.R.success(1)&&strcmp(L.R.snapshot,S.snapshot);end
 for name={'Results.mat','OuterTruth.mat','OuterSample.csv'}
  if isfile(fullfile(folder,name{1})),files{end+1}=fullfile(rel,name{1});end %#ok<AGROW>
 end
 % Completed Results.mat already contains all four target error distributions.
 % Retain partial per-draw checkpoints in the return ZIP only when needed.
 if ~ssComplete
  F=dir(fullfile(folder,'ss_inner','*.mat'));
  for k=1:numel(F),files{end+1}=fullfile(rel,'ss_inner',F(k).name);end %#ok<AGROW>
 end
end
zipFile=fullfile(root,['v57_simulation_results_B399_' char(datetime('now','Format','yyyyMMdd_HHmmss')) '.zip']);
zip(zipFile,files,root);fprintf('Return archive: %s\nOriginal per-draw restart files are retained on the cluster.\n',zipFile);
end
