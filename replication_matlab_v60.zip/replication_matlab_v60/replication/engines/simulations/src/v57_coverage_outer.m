function [raw,truth,info]=v57_coverage_outer(C,r)
% Same local posterior-residual DGP as the previous coverage experiment.
opts=struct('dataset','NASA','production',struct('rebaseData',true,'trailingMonths',60, ...
 'averageAcceleration',struct('enabled',true,'T0',C.actualT0)), ...
 'simulation',struct('dgpMode','localPosteriorResidual'));
[raw,allTruth,info]=simulate_outer_sample_local(C.raw,C.sampleIndex,C.sample,C.est,opts,40260820+100000*r);
truth=allTruth([1 3 5 7]);info.allTruth=allTruth;
end
function [simRaw, truth, info] = simulate_outer_sample_local(raw, sampleIndex, sample, est, opts, seed)

    rng(seed, 'twister');

    params = est.paramsHat;
    setup = est.setup;
    T = sample.T;
    m = setup.stateDim;
    alpha = nan(m, T);
    F = state_transition_from_params_local(params, setup);
    H = setup.H(:)';
    y = nan(T, 1);

    switch lower(opts.simulation.dgpMode)
        case {'unconditionalforward', 'unconditional', 'forward'}
            switch lower(opts.simulation.initialState)
                case 'fixedsmoothedmean'
                    alpha(:, 1) = est.smoother.alphaSmooth(:, 1);
                case 'drawsmoothed'
                    alpha(:, 1) = draw_mvn_local(est.smoother.alphaSmooth(:, 1), ...
                        est.smoother.PSmooth(:, :, 1));
                otherwise
                    error('Unknown simulation.initialState option: %s', opts.simulation.initialState);
            end

            if sample.yObserved(1)
                y(1) = H * alpha(:, 1) + sample.W(1, :) * params.beta;
            end
            for t = 2:T
                alpha(:, t) = F * alpha(:, t-1) + draw_state_noise_local(params, setup, t);
                if sample.yObserved(t)
                    y(t) = H * alpha(:, t) + sample.W(t, :) * params.beta;
                end
            end

        case {'parametricforward', 'matchedparametric', 'forwardconditional'}
            initialization = 'fixedInitial';
            if isfield(opts.simulation, 'parametricInitialization') && ...
                    ~isempty(opts.simulation.parametricInitialization)
                initialization = char(opts.simulation.parametricInitialization);
            end

            switch lower(initialization)
                case {'fixedinitial', 'fixed1880'}
                    % A literal forward bootstrap conditional on the fitted
                    % first-month state.  This is paired with the identically
                    % named inner-bootstrap initialization.
                    alpha(:, 1) = est.smoother.alphaSmooth(:, 1);
                    if sample.yObserved(1)
                        y(1) = H * alpha(:, 1) + sample.W(1, :) * params.beta;
                    end
                    simulationStart = 2;

                case {'conditionalprefix', 'conditional1970', 'prefix'}
                    anchor = outer_anchor_index_local(sample, opts.simulation);
                    % The prefix is held fixed on the estimation scale.  It
                    % is rebased together with the simulated suffix when the
                    % pseudo-sample is passed back through production code.
                    y(1:anchor) = sample.y(1:anchor);
                    alpha(:, anchor) = draw_mvn_local(est.filter.aFilt(:, anchor), ...
                        est.filter.PFilt(:, :, anchor));
                    simulationStart = anchor + 1;

                otherwise
                    error('Unknown simulation.parametricInitialization: %s', initialization);
            end

            for t = simulationStart:T
                alpha(:, t) = F * alpha(:, t-1) + draw_state_noise_local(params, setup, t);
                if sample.yObserved(t)
                    y(t) = H * alpha(:, t) + sample.W(t, :) * params.beta;
                end
            end

        case {'localposteriorresidual', 'localposterior', 'conditional'}
            % A local DGP for the concern motivating the anchored bootstrap:
            % retain a full x-v-a path drawn from the calibrated posterior,
            % then regenerate only the ARMA residual component.  This makes
            % simulated temperature histories resemble the observed record
            % while preserving a known latent state for coverage calculations.
            alpha = simulation_smoother_draw_local(est.filter, est.smoother, F);
            residIdx = 4:m;
            for t = 2:T
                shock = draw_state_noise_local(params, setup, t);
                alpha(residIdx, t) = F(residIdx, residIdx) * alpha(residIdx, t-1) + shock(residIdx);
            end
            for t = 1:T
                if sample.yObserved(t)
                    y(t) = H * alpha(:, t) + sample.W(t, :) * params.beta;
                end
            end

        otherwise
            error('Unknown simulation.dgpMode option: %s', opts.simulation.dgpMode);
    end

    simRaw = raw;
    yRaw = nan(height(raw), 1);
    yRaw(sampleIndex) = y;
    simRaw.(opts.dataset) = yRaw;

    rebaseShift = 0;
    if opts.production.rebaseData
        tRaw = double(raw.t(:));
        ref = (tRaw >= 1991) & (tRaw < 2021) & isfinite(yRaw);
        if ~any(ref)
            error('No simulated observations are available for 1991--2020 rebasing.');
        end
        rebaseShift = 0.88 - mean(yRaw(ref));
    end

    x = alpha(1, :) + rebaseShift;
    v = alpha(2, :);
    a = alpha(3, :);
    L = min(opts.production.trailingMonths, T);
    tail = (T-L+1):T;
    truth = [x(end), mean(x(tail)), 10*v(end), 10*mean(v(tail)), ...
             100*a(end), 100*mean(a(tail))];
    if average_acceleration_enabled_local(opts)
        truth(end + 1) = average_acceleration_from_velocity_local( ...
            10 * v, sample.t, opts.production.averageAcceleration);
    end

    info = struct();
    info.rebaseShift = rebaseShift;
    info.alpha = alpha;
    info.dgpMode = opts.simulation.dgpMode;
end

%% ========================================================================

function anchor = outer_anchor_index_local(sample, simulationOpts)

    anchorYear = 1970;
    if isfield(simulationOpts, 'anchorYear') && ~isempty(simulationOpts.anchorYear)
        anchorYear = simulationOpts.anchorYear;
    end
    validateattributes(anchorYear, {'numeric'}, {'scalar', 'finite'});
    anchor = find(sample.t >= anchorYear, 1, 'first');
    if isempty(anchor) || anchor >= sample.T
        error('simulation.anchorYear must lie inside the estimation sample before its endpoint.');
    end
    if ~sample.yObserved(anchor)
        error('The selected simulation anchor month has a missing observation.');
    end
end

%% ========================================================================

function F = state_transition_from_params_local(params, setup)

    dt = setup.dt;
    m = setup.stateDim;
    F = zeros(m, m);
    F(1:3, 1:3) = [1, dt, 0.5*dt^2; 0, 1, dt; 0, 0, 1];

    r0 = 4;
    p = setup.arOrder;
    q = setup.maOrder;
    if p > 0
        F(r0, r0:(r0+p-1)) = params.ar(:)';
    end
    if q > 0
        e0 = r0 + p;
        F(r0, e0:(e0+q-1)) = params.maCoeffs(:)';
    end
    for i = 2:p
        F(r0+i-1, r0+i-2) = 1;
    end
    for j = 2:q
        F(r0+p+j-1, r0+p+j-2) = 1;
    end
end

%% ========================================================================

function shock = draw_state_noise_local(params, setup, t)

    xvaShock = draw_mvn_local(zeros(3, 1), params.q * setup.SigmaXVA);

    scale = 1;
    if setup.useMonthlyVariance
        scale = scale * exp(params.gamma(setup.month(t)));
    end
    if numel(params.delta) >= setup.era(t)
        scale = scale * exp(params.delta(setup.era(t)));
    end
    Rt = max(params.sig2u * scale, setup.minVariance);
    u = sqrt(Rt) * randn;
    residShock = zeros(setup.residDim, 1);
    if setup.residDim > 0
        residShock(1) = u;
    end
    if setup.maOrder > 0
        residShock(setup.arOrder + 1) = u;
    end
    shock = [xvaShock; residShock];
end

%% ========================================================================

function x = draw_mvn_local(mu, Sigma)

    Sigma = 0.5 * (Sigma + Sigma');
    [V, D] = eig(Sigma);
    d = max(real(diag(D)), 0);
    x = mu(:) + V * (sqrt(d) .* randn(numel(mu), 1));
end

%% ========================================================================

function alphaDraw = simulation_smoother_draw_local(filt, sm, F)

    T = size(filt.aFilt, 2);
    m = size(filt.aFilt, 1);
    alphaDraw = nan(m, T);
    alphaDraw(:, T) = draw_mvn_local(sm.alphaSmooth(:, T), ...
        regularize_cov_local(sm.PSmooth(:, :, T)));

    for t = T-1:-1:1
        Ptt = regularize_cov_local(filt.PFilt(:, :, t));
        Ptpred = regularize_cov_local(filt.PPred(:, :, t+1));
        Jt = (Ptt * F') / Ptpred;
        mt = filt.aFilt(:, t) + Jt * (alphaDraw(:, t+1) - filt.aPred(:, t+1));
        Ct = regularize_cov_local(Ptt - Jt * Ptpred * Jt');
        alphaDraw(:, t) = draw_mvn_local(mt, Ct);
    end
end

%% ========================================================================

function tf = average_acceleration_enabled_local(opts)

    tf = isfield(opts, 'production') && isstruct(opts.production) && ...
        isfield(opts.production, 'averageAcceleration') && ...
        isstruct(opts.production.averageAcceleration) && ...
        isfield(opts.production.averageAcceleration, 'enabled') && ...
        logical(opts.production.averageAcceleration.enabled);
end

%% ========================================================================

function average = average_acceleration_from_velocity_local(v, t, averageOpts)

    if ~isfield(averageOpts, 'T0') || ~isscalar(averageOpts.T0) || ...
            ~isfinite(averageOpts.T0)
        error('production.averageAcceleration.T0 must be a finite scalar year.');
    end
    t = t(:);
    v = v(:);
    i0 = find(t >= averageOpts.T0, 1, 'first');
    if isempty(i0) || i0 >= numel(t)
        error('production.averageAcceleration.T0 must lie inside the sample before T.');
    end
    elapsedDecades = (t(end) - t(i0)) / 10;
    if ~isfinite(elapsedDecades) || elapsedDecades <= 0
        error('Average-acceleration elapsed time is not positive.');
    end
    average = (v(end) - v(i0)) / elapsedDecades;
end

%% ========================================================================

function S = regularize_cov_local(S)

    S = 0.5 * (S + S');
    [V, D] = eig(S);
    d = diag(D);
    d(~isfinite(d)) = 0;
    d = max(real(d), 1e-10);
    S = V * diag(d) * V';
    S = 0.5 * (S + S');
end

%% ========================================================================
