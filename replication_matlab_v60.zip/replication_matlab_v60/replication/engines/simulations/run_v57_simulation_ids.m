function run_v57_simulation_ids(kind,ids,nWorkers,mode)
% Recovery runner. IDs are job IDs (accuracy) or outer-replication IDs (coverage).
if nargin<3,nWorkers=20;end
if nargin<4,mode='production';end
[root,~,C,S]=prepare_v57_simulations(mode);
assert(ismember(string(kind),["accuracy","coverage"]));
validateattributes(nWorkers,{'numeric'},{'scalar','integer','positive'});
if strcmp(kind,'accuracy'),limit=5*S.accuracyR;folder=S.accuracyDir;else,limit=S.coverageR;folder=S.coverageDir;end
if isempty(ids),fprintf('No requested jobs.\n');return;end
validateattributes(ids,{'numeric'},{'vector','integer','>=',1,'<=',limit});assert(numel(unique(ids))==numel(ids));
if ~isfolder(folder),mkdir(folder);end
if nWorkers>1
 p=gcp('nocreate');if ~isempty(p)&&p.NumWorkers~=nWorkers,delete(p);p=[];end
 if isempty(p)
  c=parcluster('local');storage=tempname;mkdir(storage);c.JobStorageLocation=storage;parpool(c,nWorkers);
 end
end
if strcmp(kind,'accuracy')
 % Worker count affects concurrency only, never scientific job allocation.
 if nWorkers>1
  parfor k=1:numel(ids),v57_accuracy_one(C,S,ids(k),root);end
 else
  for k=1:numel(ids),v57_accuracy_one(C,S,ids(k),root);end
 end
else
 % Outer samples sequential within each array; SS inner draws use the pool.
 for k=1:numel(ids),v57_coverage_one(C,S,ids(k),nWorkers,root);end
end
end
