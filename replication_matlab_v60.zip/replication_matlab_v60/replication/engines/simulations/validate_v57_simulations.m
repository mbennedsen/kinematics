function validate_v57_simulations
[root,~,C,S]=prepare_v57_simulations('smoke');
assert(C.cfg.nRep==1000 && numel(C.selected)==5);
for N=[5000 400]
 for na=[1 12 32]
  ids=[];for a=1:na,ids=[ids a:na:N];end %#ok<AGROW>
  assert(isequal(sort(ids),1:N),'Allocation has gaps or overlaps.');
 end
end
for d=C.selected
 x=simulate_four_estimator_dgp_v2(C,d,1);y=simulate_four_estimator_dgp_v2(C,d,1);
 assert(isequaln(x,y));assert(all(isfinite(x.truth)));
end
[a,t,i]=v57_coverage_outer(C,1);[b,u,j]=v57_coverage_outer(C,1);
assert(isequaln(a,b)&&isequaln(t,u)&&isequaln(i,j));
assert(abs(t(4)-100*(i.alpha(2,end)-i.alpha(2,C.index0))/10)<1e-10);
assert(abs(t(1)-(i.alpha(1,end)+i.rebaseShift))<1e-10);
o=C.empiricalOptions.ss;o.datasets={'NASA'};o.outputDir=tempname(fullfile(root,'validation'));o.bootstrap.B=0;o.bootstrap.useParallel=false;o.bootstrap.pathBands=false;
clean=onCleanup(@()rmdir(o.outputDir,'s'));
evalc('f=estimate_ss_v57_simulation(fullfile(root,''inputs'',''ObservedData.csv''),o);');E=f.detail.NASA;
assert(abs(E.pointEstimate.logLik-C.est.logLik)<1e-6,'Empirical likelihood not reproduced.');
assert(max(abs(E.sampleData.y-C.sample.y))<1e-12 && max(abs(E.sampleData.W-C.sample.W),[],'all')<1e-12);
assert(max(abs(E.pointEstimate.smoother.alphaSmooth(1:3,:)-C.est.smoother.alphaSmooth(1:3,:)),[],'all')<1e-5);
assert(abs(o.bootstrap.ciAlpha-.1)<eps && abs(C.empiricalOptions.kernel.bootstrap.ciAlpha-.1)<eps);
assert(strcmpi(o.bootstrap.inferenceMode,'bootstrapError')&&strcmpi(o.bootstrap.method,'posteriorResidual'));
fprintf('PASS: allocations, deterministic DGPs, paired truth/rebasing, and v57 empirical likelihood/paths.\n');
end
