clear; close all;
ARRAY_INDEX=1; % Run 1,2,...,12.
nArrays=12;
nWorkers=20;
run_v57_accuracy(ARRAY_INDEX,nArrays,nWorkers);
