function [root,snapshot,C,S]=prepare_v57_simulations(mode)
% Read-only verification. Preparation is already frozen; safe in every array.
if nargin<1,mode='production';end
root=fileparts(mfilename('fullpath'));addpath(root,fullfile(root,'src'),'-begin');
assert(ismember(string(mode),["production","smoke"]),'Use production or smoke.');
f=fullfile(root,'SHA256SUMS.tsv');assert(isfile(f),'Frozen manifest missing.');
fid=fopen(f);c=onCleanup(@()fclose(fid));H=textscan(fid,'%s%s','Delimiter','\t');
for k=1:numel(H{1})
 path=fullfile(root,H{2}{k});assert(isfile(path),'Missing frozen file: %s',H{2}{k});
 assert(strcmp(simulation_file_sha256(path),H{1}{k}),'Frozen code/input changed: %s. Preserve results; use a new package.',H{2}{k});
end
snapshot=simulation_file_sha256(f);L=load(fullfile(root,'inputs','Calibration.mat'),'C');C=L.C;
assert(C.schemaVersion==57 && C.sample.T==1748 && abs(C.endTime-C.actualT0-10)<1e-8);
assert(isequal(C.fitOptions.covariates.maxLags,[12 12 12]) && isequal(C.fitOptions.covariates.almonDegrees,[2 1 1]));
s=C.fitOptions.stateSpace;assert(s.arOrder==1 && s.maOrder==1 && s.useMonthlyVariance && isempty(s.varianceBreakYears) && isempty(s.fixedQ));
S=struct('mode',char(mode),'accuracyR',1000,'coverageR',400,'B',399,'snapshot',snapshot);
if strcmp(mode,'smoke'),S.accuracyR=1;S.coverageR=1;S.B=19;prefix=fullfile(root,'validation');else,prefix=root;end
S.accuracyDir=fullfile(prefix,sprintf('accuracy_R%d',S.accuracyR));
S.coverageDir=fullfile(prefix,sprintf('coverage_R%d_B%d',S.coverageR,S.B));
fprintf('PASS: v57 calibration + %d frozen files; %s: accuracy 5 x %d, coverage %d x B=%d.\n',numel(H{1}),mode,S.accuracyR,S.coverageR,S.B);
end
