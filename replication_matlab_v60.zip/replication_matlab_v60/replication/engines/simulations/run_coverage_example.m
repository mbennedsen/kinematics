clear; close all;
ARRAY_INDEX=1; % Run 1,2,...,12, as a separate set of jobs from accuracy.
nArrays=12;
nWorkers=20;
run_v57_coverage(ARRAY_INDEX,nArrays,nWorkers);
