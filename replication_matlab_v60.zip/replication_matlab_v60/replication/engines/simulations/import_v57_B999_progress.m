function counts=import_v57_B999_progress(donor,kind,mode)
% Import verified B999 progress BEFORE launching this B399 package.
% Stop donor jobs first. Originals are read only; final coverage intervals are
% never copied. SS draws 1:399 have the same seeds and are reused on resumption.
if nargin<2,kind='all';end
if nargin<3,mode='production';end
assert(ismember(string(kind),["all","accuracy","coverage"]));
[root,snapshot,C,S]=prepare_v57_simulations(mode);
reference=fullfile(root,'migration','Source_B999_SHA256SUMS.tsv');
oldSnapshot=simulation_file_sha256(reference);
assert(strcmp(simulation_file_sha256(fullfile(donor,'SHA256SUMS.tsv')),oldSnapshot), ...
 'Donor is not the supported frozen B999 package.');
fid=fopen(reference);cleanup=onCleanup(@()fclose(fid));
H=textscan(fid,'%s%s','Delimiter','\t');
for j=1:numel(H{1})
 name=H{2}{j};file=fullfile(donor,name);
 assert(strcmp(simulation_file_sha256(file),H{1}{j}),'Changed donor file: %s',name);
 if strcmp(name,'prepare_v57_simulations.m')
  assert(strcmp(strrep(fileread(file),'''B'',999','''B'',399'), ...
   fileread(fullfile(root,name))),'Unexpected preparation-code difference.');
 else
  assert(strcmp(simulation_file_sha256(fullfile(root,name)),H{1}{j}), ...
   'Scientific code/input differs: %s',name);
 end
end
clear cleanup
prefix=donor;oldB=999;
if strcmp(mode,'smoke'),prefix=fullfile(donor,'validation');oldB=19;end
doAccuracy=ismember(string(kind),["all","accuracy"]);
doCoverage=ismember(string(kind),["all","coverage"]);
if doAccuracy,assert(~isfolder(S.accuracyDir),'Import before creating target accuracy results.');end
if doCoverage,assert(~isfolder(S.coverageDir),'Import before creating target coverage results.');end
stage=tempname(root);mkdir(stage);cleanup=onCleanup(@()rmdir(stage,'s'));
accuracyStage=fullfile(stage,'accuracy');coverageStage=fullfile(stage,'coverage');
counts=struct('accuracyFiles',0,'coverageSamples',0,'pointFits',0,'ssDraws',0);
if doAccuracy
 mkdir(accuracyStage);
 source=fullfile(prefix,sprintf('accuracy_R%d',S.accuracyR));
 F=dir(fullfile(source,'job_*.mat'));
 for j=1:numel(F)
  L=load(fullfile(source,F(j).name),'R');R=L.R;
  assert(strcmp(R.snapshot,oldSnapshot)&&strcmp(R.mode,mode));
  assert(R.job>=1&&R.job<=5*S.accuracyR&&R.job==floor(R.job));
  assert(strcmp(F(j).name,sprintf('job_%05d.mat',R.job)));
  assert(R.rep==mod(R.job-1,S.accuracyR)+1 && ...
   R.dgp==C.selected(floor((R.job-1)/S.accuracyR)+1));
  R.importedFromSnapshot=oldSnapshot;R.snapshot=snapshot;
  v57_atomic_save(fullfile(accuracyStage,F(j).name),R);
  counts.accuracyFiles=counts.accuracyFiles+1;
 end
end
if doCoverage
 mkdir(coverageStage);
 source=fullfile(prefix,sprintf('coverage_R%d_B%d',S.coverageR,oldB));
 for rep=1:S.coverageR
  rel=sprintf('rep_%04d',rep);from=fullfile(source,rel);
  outer=fullfile(from,'OuterTruth.mat');
  if ~isfile(outer),continue;end
  L=load(outer,'R');R=L.R;
  oldKey=[oldSnapshot ':' mode ':' num2str(rep)];
  newKey=[snapshot ':' mode ':' num2str(rep)];
  assert(strcmp(R.key,oldKey)&&R.seed==40260820+100000*rep);
  assert(strcmp(R.inputSHA,simulation_file_sha256(fullfile(from,'OuterSample.csv'))));
  to=fullfile(coverageStage,rel);mkdir(to);
  copyfile(fullfile(from,'OuterSample.csv'),fullfile(to,'OuterSample.csv'));
  oldInnerKey=[oldKey ':' R.inputSHA];newInnerKey=[newKey ':' R.inputSHA];
  R.key=newKey;R.importedFromSnapshot=oldSnapshot;
  v57_atomic_save(fullfile(to,'OuterTruth.mat'),R);
  counts.coverageSamples=counts.coverageSamples+1;
  point=fullfile(from,'ss_inner','PointFit.mat');
  if ~isfile(point),continue;end
  P=load(point);assert(strcmp(P.key,oldInnerKey));
  inner=fullfile(to,'ss_inner');mkdir(inner);P.key=newInnerKey;
  save(fullfile(inner,'PointFit.mat'),'-struct','P','-v7');
  counts.pointFits=counts.pointFits+1;
  for b=1:S.B
   name=sprintf('draw_%05d.mat',b);file=fullfile(from,'ss_inner',name);
   if ~isfile(file),continue;end
   D=load(file);assert(strcmp(D.key,oldInnerKey)&&D.seed==40260820+100000*rep+1000+b);
   assert(all(isfield(D,{'xRow','vRow','aRow','averageAccelerationRow','pathError'})));
   D.key=newInnerKey;save(fullfile(inner,name),'-struct','D','-v7');
   counts.ssDraws=counts.ssDraws+1;
  end
 end
end
% Publish only after every source file/checkpoint has passed validation.
if doAccuracy
 parent=fileparts(S.accuracyDir);if ~isfolder(parent),mkdir(parent);end
 movefile(accuracyStage,S.accuracyDir);
end
if doCoverage
 parent=fileparts(S.coverageDir);if ~isfolder(parent),mkdir(parent);end
 movefile(coverageStage,S.coverageDir);
end
fprintf('Imported %d accuracy files, %d outer samples, %d point fits, %d SS draws.\n', ...
 counts.accuracyFiles,counts.coverageSamples,counts.pointFits,counts.ssDraws);
fprintf('Run the usual arrays next. Coverage intervals will be recomputed with B=%d.\n',S.B);
end
