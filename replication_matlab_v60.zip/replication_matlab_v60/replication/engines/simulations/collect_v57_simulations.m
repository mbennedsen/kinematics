function out=collect_v57_simulations(nArrays,mode)
% Partial results are reported explicitly; missing/failed IDs can be rerun.
if nargin<1,nArrays=12;end
if nargin<2,mode='production';end
[root,~,C,S]=prepare_v57_simulations(mode);
validateattributes(nArrays,{'numeric'},{'scalar','integer','positive'});
methods={'ss','kernel','quadratic','changepoint'};objects={'x_T','v_T','a_T','average_a_past_decade'};
Arows=struct([]);Asummary=struct([]);missingA=[];retryA=[];Aok=false(5*S.accuracyR,1);Apresent=Aok;
for di=1:5
 errors=nan(S.accuracyR,4,4);attempted=0;
 for r=1:S.accuracyR
  job=(di-1)*S.accuracyR+r;f=fullfile(S.accuracyDir,sprintf('job_%05d.mat',job));
  if ~isfile(f),missingA(end+1)=job;continue;end %#ok<AGROW>
  L=load(f,'R');R=L.R;assert(strcmp(R.snapshot,S.snapshot)&&strcmp(R.mode,S.mode)&&R.job==job&&R.rep==r&&R.dgp==C.selected(di));
  attempted=attempted+1;Apresent(job)=true;Aok(job)=all(R.success);if ~Aok(job),retryA(end+1)=job;end %#ok<AGROW>
  for m=1:4
   if R.success(m),errors(r,m,:)=R.estimates(m,:)-R.truth;end
   for k=1:4
    z=struct('JobID',job,'DGP',string(C.scenarios{C.selected(di)}),'Replication',r,'Method',string(methods{m}), ...
     'Estimand',string(objects{k}),'Success',R.success(m),'Truth',R.truth(k),'Estimate',R.estimates(m,k),'ErrorMessage',R.message(m));
    if isempty(Arows),Arows=z;else,Arows(end+1)=z;end %#ok<AGROW>
   end
  end
 end
 for m=1:4
  for k=1:4
   e=errors(:,m,k);e=e(isfinite(e));n=numel(e);rmse=sqrt(mean(e.^2));
   z=struct('DGP',string(C.scenarios{C.selected(di)}),'Method',string(methods{m}),'Estimand',string(objects{k}), ...
    'Planned',S.accuracyR,'Returned',attempted,'Valid',n,'Failed',attempted-n,'Bias',mean(e), ...
    'BiasMCSE',std(e)/sqrt(n),'RMSE',rmse,'RMSE_MCSE',std(e.^2)/sqrt(n)/(2*max(rmse,eps)));
   if isempty(Asummary),Asummary=z;else,Asummary(end+1)=z;end %#ok<AGROW>
  end
 end
end
Crows=struct([]);missingC=[];retryC=[];Cok=false(S.coverageR,1);Cpresent=Cok;
for r=1:S.coverageR
 f=fullfile(S.coverageDir,sprintf('rep_%04d',r),'Results.mat');
 if ~isfile(f),missingC(end+1)=r;continue;end %#ok<AGROW>
 L=load(f,'R');R=L.R;assert(strcmp(R.snapshot,S.snapshot)&&strcmp(R.mode,S.mode)&&R.rep==r&&R.B==S.B);
 input=fullfile(fileparts(f),'OuterSample.csv');assert(strcmp(R.inputSHA,simulation_file_sha256(input)));
 L=load(fullfile(fileparts(f),'OuterTruth.mat'),'R');assert(isequaln(R.truth,L.R.truth));
 Cpresent(r)=true;Cok(r)=all(R.success);if ~Cok(r),retryC(end+1)=r;end %#ok<AGROW>
 for m=1:4
  for k=1:4
   structural=m==4&&k==3;ok=R.success(m)&&~structural;
   cov=NaN;lm=NaN;um=NaN;len=NaN;
   if ok,cov=double(R.low(m,k)<=R.truth(k)&&R.truth(k)<=R.high(m,k));lm=double(R.low(m,k)>R.truth(k));um=double(R.high(m,k)<R.truth(k));len=R.high(m,k)-R.low(m,k);end
   z=struct('Replication',r,'Method',string(methods{m}),'Estimand',string(objects{k}),'Success',R.success(m),'StructuralZero',structural, ...
    'Truth',R.truth(k),'Point',R.point(m,k),'Low',R.low(m,k),'High',R.high(m,k),'Coverage',cov,'LowerMiss',lm,'UpperMiss',um, ...
    'IntervalLength',len,'ValidInnerDraws',R.validDraws(m,k),'ErrorMessage',R.message(m));
   if isempty(Crows),Crows=z;else,Crows(end+1)=z;end %#ok<AGROW>
  end
 end
end
cs=struct([]);if isempty(Crows),T=table();else,T=struct2table(Crows);end
for m=1:4
 for k=1:4
  if isempty(T),z=T;else,z=T(T.Method==methods{m}&T.Estimand==objects{k},:);end
  structural=m==4&&k==3;n=0;np=0;bias=NaN;len=NaN;minB=NaN;maxB=NaN;est=nan(1,3);se=est;wl=est;wh=est;
  if ~isempty(z)
   good=z.Success;np=sum(good);bias=mean(z.Point(good)-z.Truth(good));
   q=z(good&~z.StructuralZero,:);n=height(q);
   if n>0
    val=[q.Coverage,q.LowerMiss,q.UpperMiss];est=mean(val,1);se=sqrt(est.*(1-est)/n);[wl,wh]=wilson_local(sum(val,1),n);
    len=mean(q.IntervalLength);minB=min(q.ValidInnerDraws);maxB=max(q.ValidInnerDraws);
   end
  end
  r=struct('Method',string(methods{m}),'Estimand',string(objects{k}),'Planned',S.coverageR,'Returned',height(z), ...
   'ValidPoints',np,'Failed',height(z)-np,'ValidIntervals',n,'StructuralZero',structural,'Coverage',est(1),'CoverageMCSE',se(1), ...
   'CoverageWilsonLow',wl(1),'CoverageWilsonHigh',wh(1),'LowerMiss',est(2),'LowerMissMCSE',se(2), ...
   'LowerMissWilsonLow',wl(2),'LowerMissWilsonHigh',wh(2),'UpperMiss',est(3),'UpperMissMCSE',se(3), ...
   'UpperMissWilsonLow',wl(3),'UpperMissWilsonHigh',wh(3),'Bias',bias,'MeanLength',len,'B',S.B,'MinValidInner',minB,'MaxValidInner',maxB);
  if isempty(cs),cs=r;else,cs(end+1)=r;end %#ok<AGROW>
 end
end
summary=fullfile(root,'summary');if strcmp(mode,'smoke'),summary=fullfile(root,'validation','summary');end
if ~isfolder(summary),mkdir(summary);end
writetable(struct2table(Asummary),fullfile(summary,'AccuracySummary.csv'));
if ~isempty(Arows),writetable(struct2table(Arows),fullfile(summary,'AccuracyReplications.csv'));end
writetable(struct2table(cs),fullfile(summary,'CoverageSummary.csv'));
if ~isempty(Crows),writetable(T,fullfile(summary,'CoverageReplications.csv'));end
out=struct('missingAccuracy',missingA,'retryAccuracy',retryA,'missingCoverage',missingC,'retryCoverage',retryC, ...
 'accuracyComplete',all(Aok),'coverageComplete',all(Cok),'snapshot',S.snapshot,'mode',mode);
for label={'missingAccuracy','retryAccuracy','missingCoverage','retryCoverage'}
 ids=out.(label{1});writetable(table(ids(:),'VariableNames',{'JobID'}),fullfile(summary,[label{1} '.csv']));
end
P=table((1:nArrays)','VariableNames',{'ArrayIndex'});
for name={'AccuracyAssigned','AccuracyMissing','AccuracyRetry','CoverageAssigned','CoverageMissing','CoverageRetry'},P.(name{1})=zeros(nArrays,1);end
for a=1:nArrays
 ia=a:nArrays:numel(Aok);ic=a:nArrays:numel(Cok);
 P.AccuracyAssigned(a)=numel(ia);P.AccuracyMissing(a)=sum(~Apresent(ia));P.AccuracyRetry(a)=sum(Apresent(ia)&~Aok(ia));
 P.CoverageAssigned(a)=numel(ic);P.CoverageMissing(a)=sum(~Cpresent(ic));P.CoverageRetry(a)=sum(Cpresent(ic)&~Cok(ic));
end
writetable(P,fullfile(summary,'ArrayProgress.csv'));save(fullfile(summary,'Collection.mat'),'out','S');
fprintf('ACCURACY: %d/%d complete; %d missing; %d need retry.\n',sum(Aok),numel(Aok),numel(missingA),numel(retryA));
fprintf('COVERAGE: %d/%d complete; %d missing; %d need retry; B=%d.\n',sum(Cok),numel(Cok),numel(missingC),numel(retryC),S.B);
if ~all(Aok)||~all(Cok),fprintf('INCOMPLETE: do not treat partial summaries as final.\n');end
disp(P);
end
function [lo,hi]=wilson_local(k,n)
z=1.95996398454005;p=k/n;den=1+z^2/n;c=(p+z^2/(2*n))/den;h=z*sqrt(p.*(1-p)/n+z^2/(4*n^2))/den;lo=c-h;hi=c+h;
end
