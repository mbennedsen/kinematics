V57 ACCURACY AND PAIRED COVERAGE STUDIES
======================================

The retained empirical specification is unchanged: monthly NASA, January 1881
through August 2026, ARMA(1,1), monthly innovation variances, no historical variance
breaks, covariate lags (12,12,12), Almon degrees (2,1,1). The input is the corrected
ordinary HadISST Niño 3.4 extension used for v57, not relative ENSO. The calibration
is the actual saved v57 empirical fit, NOT the shorter common-sample specification
search. The past-decade window is August 2016--August 2026 (120 monthly intervals).

Production settings are frozen:
  ACCURACY: five designs x 1,000 outer replications; four estimators, no bootstrap.
  COVERAGE: 400 shared outer samples; 399 inner draws for SS, kernel and changepoint.
            Quadratic intervals use their existing Newey-West HAC procedure.
  COVERAGE TARGET: nominal 90% two-sided intervals; 5% nominal miss in each tail.
  TARGETS: endpoint warming level, rate, acceleration, and past-decade acceleration.

SWITCHING FROM THE B999 RUNS
----------------------------
The previous v55 coverage setting was B=399; this package restores it. There are
400 outer replications as before. Accuracy uses no inner bootstrap and is unchanged.
Stop the old coverage jobs before migrating; do not overwrite the B999 package.
Extract this package into its own folder and start MATLAB there. To preserve work,
stop donor jobs and import once, before starting any new arrays:

    import_v57_B999_progress('/absolute/path/to/old_B999_package');

The donor must be the original full cluster folder, including source, inputs,
SHA256SUMS.tsv and per-draw ss_inner checkpoints. The import verifies every frozen
source/input file, then copies accuracy results unchanged apart from provenance,
and copies coverage outer samples, point fits and SS draws with indices 1:399.
It never modifies the donor or copies its 999-draw final intervals. The new run
rebuilds SS intervals from 399 draws, computing only missing draws. Kernel and
changepoint intervals are recomputed; quadratic HAC is recomputed unchanged.
Do not manually copy results: the new package has a different snapshot identity.
Import requires the selected target result directories not to exist yet.

If accuracy is still running, it can continue in the old folder. Import coverage
only now (after stopping old coverage jobs):

    import_v57_B999_progress('/absolute/path/to/old_B999_package','coverage');

Later, after accuracy finishes/stops, import it separately:

    import_v57_B999_progress('/absolute/path/to/old_B999_package','accuracy');

Do not rerun complete accuracy jobs. If any remain, the usual accuracy arrays
resume them. Import is optional: without it, this package starts a fresh study.
Reducing B from 999 to 399 removes about 60% of inner draws; total wall-clock
savings depend on the fitting overhead and the progress already saved.

CLUSTER LAUNCH
--------------
Extract/copy the entire package into a NEW folder. Start MATLAB in that folder,
or add its absolute path. No parent project folders or downloads are needed.
MATLAB plus Optimization Toolbox is required. Multiple workers require Parallel
Computing Toolbox. Development validation used R2025b.

Accuracy: run a separate job for each ARRAY_INDEX = 1,2,...,12:

    clear; close all;
    ARRAY_INDEX=1;
    nArrays=12;
    nWorkers=20;
    run_v57_accuracy(ARRAY_INDEX,nArrays,nWorkers);

Coverage: run another set of jobs, also ARRAY_INDEX = 1,2,...,12:

    clear; close all;
    ARRAY_INDEX=1;
    nArrays=12;
    nWorkers=20;
    run_v57_coverage(ARRAY_INDEX,nArrays,nWorkers);

The two studies may run concurrently in separate MATLAB processes, subject to
allocated cluster resources. Example scripts are run_accuracy_example.m and
run_coverage_example.m. Use your usual scheduler launcher; no scheduler is assumed.

With 12 arrays: accuracy has 416 or 417 jobs per array, coverage has 33 or 34
outer replications per array. Accuracy parallelizes across outer replications;
coverage processes its outer replications sequentially and parallelizes the SS
inner draws. Kernel bootstrap is serial; changepoint draws use its existing
vectorized full-breakpoint-search implementation.

WORKER COUNTS, PREPARATION AND RESUMPTION
---------------------------------------
Job assignment is arrayIndex:nArrays:nJobs and NEVER depends on nWorkers. Worker
counts can change safely. Keep nArrays consistent across simultaneously running
jobs; do not launch overlapping IDs. There is no preparation race: calibration
and scientific inputs are already frozen. prepare_v57_simulations is a read-only
hash/preflight check, automatically called by each launcher. Custom launchers and
worker counts are not part of the scientific hash. Code/input changes require a
new package; do not disable hash guards or mix with v55/v56 studies.

Rerun an interrupted array with the same command. Completed estimator results are
skipped. Each accuracy replication saves after every method. Coverage saves its
outer sample/truth before fitting, saves after each method, and checkpoints each
individual SS bootstrap draw. The outer point fit is cached too, ensuring that
resumed draws use exactly the same fitted parameters. Atomic writes prevent a
partially written file from appearing complete. Method failures are retained and
retried on rerun, and are reported by the collector.

Seeds are explicit functions of outer replication, method and inner-draw index;
SS random streams do not depend on worker scheduling. The original accuracy DGPs
retain their common observation-noise stream across designs. No scientific
selection or estimation settings are changed by the checkpoint/RNG additions.

COLLECTION AND RECOVERY
-----------------------
Run either during transfer or after all jobs:

    out=collect_v57_simulations(12);

The summary folder contains:
  AccuracySummary.csv          bias, RMSE, Monte Carlo SEs, counts by design/method
  AccuracyReplications.csv     paired truth and estimate for every returned fit
  CoverageSummary.csv          coverage, lower/upper misses, bias, mean length,
                              MCSEs and 95% Wilson intervals for proportions
  CoverageReplications.csv     shared truths, points, bounds and valid inner counts
  ArrayProgress.csv            assigned/missing/failed counts by array, for both studies
  missingAccuracy.csv          accuracy job IDs not returned
  retryAccuracy.csv            accuracy job IDs with at least one failed method
  missingCoverage.csv          coverage outer IDs not returned
  retryCoverage.csv            coverage IDs with at least one failed method
  Collection.mat               same recovery IDs as the returned out struct

After stopping original jobs, distribute recovery IDs across arrays, e.g.:

    out=collect_v57_simulations(12);
    ARRAY_INDEX=1;  % 1,...,12
    ids=sort([out.missingAccuracy,out.retryAccuracy]);
    run_v57_simulation_ids('accuracy',ids(ARRAY_INDEX:12:end),20);

For coverage use missingCoverage/retryCoverage and 'coverage'. Empty ID lists are
allowed. Successful methods and completed SS draws are retained during recovery.
Partial summaries are labelled INCOMPLETE, with planned/returned/valid/failed
counts; do not quote them as final simulation results.

When finished, a compact return archive can be created with:

    export_v57_simulation_results(12);

Return that ZIP. It includes inputs, source, summaries, all accuracy results,
and each coverage sample, latent truth, estimates, intervals and raw error/draw
distributions. For completed SS fits it omits redundant per-draw checkpoint files;
these remain on the cluster. For incomplete SS fits it includes checkpoints so
recovery is possible. This avoids transferring roughly 160,000 tiny files.
Alternatively return accuracy_R1000/, coverage_R400_B399/ and summary/ directly.
Keep originals until the transferred results have been checked.

SCIENTIFIC DESIGN AND SCOPE
---------------------------
The five accuracy designs are unchanged: constant warming rate; smoothly
increasing acceleration; the NASA-derived acceleration path; the fitted quadratic
trend; and the fitted changepoint trend. Their numerical paths, ARMA/monthly
variance calibration and covariate contributions are refreshed. The existing
integration construction for the NASA-derived design is retained. The two
parametric designs retain their benchmark-specific covariate coefficients.
inputs/DGPTruth.csv gives the updated target values for all five designs.

Coverage retains the previous local posterior-residual outer DGP: draw a latent
path from the NASA smoothing distribution, regenerate the ARMA residual process,
and retain the resulting known latent truth. All four estimators see the EXACT
same outer CSV and truth. The 1991--2020 rebasing shift is applied consistently
to the level truth; rates and accelerations are invariant to that shift.

Each fit re-estimates its parameters. State-space inference uses the existing
posterior-residual/bootstrap-error procedure; kernel uses the existing 25-year
bandwidth and 24-month moving-block percentile bootstrap; changepoint inference
re-estimates all regression coefficients and reselects the breakpoint in every
ARMA(1,1) bootstrap draw. The quadratic benchmark uses its empirical HAC settings.
The changepoint endpoint acceleration is a structural zero: point bias is retained,
but no artificial confidence interval or coverage is reported for that target.
The v57 empirical right-hand slope convention is used at the averaging-window
boundary. No average-acceleration interval is formed from independent endpoint CIs.

SS stored draws are estimator-minus-truth ERRORS, and its intervals subtract their
quantiles from the point estimate. Kernel and changepoint stored draws are bootstrap
ESTIMATES and their intervals are percentile intervals. Do not pool these different
draw types. The respective empirical percentile/interpolation conventions are
preserved. A method must retain at least 95% valid bootstrap draws, matching the
empirical audit rule; valid counts are reported separately for each estimand. The
underlying production bootstrap acceptance/retry rules are retained.

This is a refreshed NASA-calibrated coverage assessment, not a fixed-null size
study or an own-model calibration test for the parametric benchmarks. The results
cannot establish calibration under every possible DGP, remove the residual LB
rejections, or establish a false-positive rate under a true rate step. No results
from the pending null study are imported or modified. Empirical bootstraps are not
rerun, and the paper is not updated by these scripts.

IMPLEMENTATION AND VALIDATION
-----------------------------
The four estimators and changepoint helpers are frozen from the v57 empirical
uncertainty package. The SS copy adds only deterministic per-draw seeding and
point/draw checkpointing. The outer coverage generator is extracted unchanged
from the prior coverage engine. Source_Provenance.json records parent hashes.
Only frozen scientific files enter SHA256SUMS.tsv; documentation, exporters and
editable launchers do not change the experiment identity.

validate_v57_simulations checks the original v57 NASA likelihood and state paths,
DGP repeatability, level rebasing, target dates, and gap-free array allocations.
A separate smoke mode runs one accuracy replication per design and one paired
coverage sample with B=19 (the minimum useful small test of the changepoint code).
Smoke output lives under validation/ and cannot mix with production:

    validate_v57_simulations;
    run_v57_accuracy(1,1,4,'smoke');
    run_v57_coverage(1,1,4,'smoke');
    collect_v57_simulations(12,'smoke');

These small tests check implementation and resumption, not statistical performance.
The production coverage B is 399. The empirical paper's intervals used B=1999;
that computational-count difference should be stated when reporting the study.
