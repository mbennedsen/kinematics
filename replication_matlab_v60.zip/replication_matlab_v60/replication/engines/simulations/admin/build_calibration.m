function build_calibration(base)
% Development only: freeze v57 empirical calibration; cluster never reruns this.
pkg=fullfile(base,'revision_v57','cluster_simulations');addpath(fullfile(pkg,'src'));
old=load(fullfile(base,'revision_v55','cluster_simulations','inputs','Calibration.mat'),'C');C=old.C;
source=fullfile(base,'revision_v56_checks','cluster_uncertainty_hadisst');
L=load(fullfile(source,'results','monthly','NASA','ss_B1999','CompletedFit.mat'),'fit');D=L.fit.detail.NASA;
C.raw=readtable(fullfile(pkg,'inputs','ObservedData.csv'));C.sample=D.sampleData;C.est=D.pointEstimate;C.fitOptions=L.fit.options;clear L D;
K=load(fullfile(source,'Configuration.mat'),'C');C.empiricalOptions=K.C.monthly.NASA;
[found,C.sampleIndex]=ismember(C.sample.t,C.raw.t);assert(all(found));
C.index0=C.sample.T-120;C.actualT0=C.sample.t(C.index0);C.endTime=C.sample.t(end);
assert(abs(C.endTime-C.actualT0-10)<1e-8);C.cfg.T0=C.actualT0;C.cfg.nRep=1000;
assert(abs(C.sample.t(1)-(1881+.5/12))<1e-8 && C.sample.T==1748);
C.x0=C.est.smoother.alphaSmooth(1,1);C.v0=C.est.smoother.alphaSmooth(2,1);C.aNASA=C.est.smoother.alphaSmooth(3,:)';
C.cfg.rampEnd=max(abs(C.aNASA));C.cfg.oscillationMean=mean(C.aNASA);C.cfg.oscillationAmplitude=range(C.aNASA)/2;
Q=load(fullfile(source,'results','monthly','NASA','quadratic_B1999','CompletedFit.mat'),'fit');
K=load(fullfile(source,'results','monthly','NASA','changepoint_B1999','point','CompletedFit.mat'),'fit');
q=Q.fit.detail.NASA;b=K.fit.detail.NASA;
Z=[];cov=C.fitOptions.covariates;n=height(C.raw);
for i=1:numel(cov.names)
 x=C.raw.(cov.names{i});if cov.standardize,x=(x-mean(x,'omitnan'))/std(x,'omitnan');end
 lagged=nan(n,cov.maxLags(i)+1);for lag=0:cov.maxLags(i),lagged(lag+1:end,lag+1)=x(1:end-lag);end
 u=(0:cov.maxLags(i))';A=zeros(numel(u),cov.almonDegrees(i)+1);for power=0:cov.almonDegrees(i),A(:,power+1)=u.^power;end
 Z=[Z,lagged*A]; %#ok<AGROW>
end
for E={q,b},[ok,ix]=ismember(E{1}.sample.t,C.raw.t);assert(all(ok));assert(max(abs(Z(ix,:)-E{1}.sample.Z),[],'all')<1e-9);end
Z=Z(C.sampleIndex,:);
C.parametric.quadratic=struct('coeff',q.coeff(1:3),'tRef',mean(q.sample.t),'beta',q.coeff(4:end),'covariateContribution',Z*q.coeff(4:end));
C.parametric.changepoint=struct('coeff',b.coeff(1:3),'tRef',b.tRef,'breakDate',b.breakDate,'beta',b.coeff(4:end),'covariateContribution',Z*b.coeff(4:end));
C.created=datestr(now,30);C.schemaVersion=57;C.selected=[1 2 4 6 7];
C=rmfield(C,intersect(fieldnames(C),{'source','id','parentCalibrationId','importedReplications'}));
save(fullfile(pkg,'inputs','Calibration.mat'),'C','-v7.3');
truth=zeros(5,4);for i=1:5,S=simulate_four_estimator_dgp_v2(C,C.selected(i),1);truth(i,:)=S.truth;end
T=array2table(truth,'VariableNames',{'x_T','v_T','a_T','average_a_past_decade'});
T=addvars(T,string(C.scenarios(C.selected))','Before',1,'NewVariableNames','DGP');writetable(T,fullfile(pkg,'inputs','DGPTruth.csv'));
p=[C.est.smoother.alphaSmooth(1,end),10*C.est.smoother.alphaSmooth(2,end),100*C.est.smoother.alphaSmooth(3,end), ...
 100*(C.est.smoother.alphaSmooth(2,end)-C.est.smoother.alphaSmooth(2,C.index0))/10];
T=array2table([C.sample.T,C.sample.t(1),C.endTime,C.actualT0,C.est.logLik,C.est.paramsHat.rho,C.est.paramsHat.ma,C.est.paramsHat.q,p], ...
 'VariableNames',{'N','Start','End','T0','LogLik','AR','MA','q','x','v','a','average_a'});writetable(T,fullfile(pkg,'inputs','CalibrationSummary.csv'));disp(T);
end
