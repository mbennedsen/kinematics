function verify_B399_revision(donor)
% Run after importing and completing the donor's B19 smoke fixtures.
root=fileparts(fileparts(mfilename('fullpath')));addpath(root,fullfile(root,'src'));
[~,snapshot,~,P]=prepare_v57_simulations;
assert(P.B==399 && P.coverageR==400 && P.accuracyR==1000);
[~,~,~,S]=prepare_v57_simulations('smoke');
old=load(fullfile(donor,'validation','coverage_R1_B19','rep_0001','Results.mat'),'R');
new=load(fullfile(S.coverageDir,'rep_0001','Results.mat'),'R');
for f={'truth','point','low','high','draws','validDraws','success'}
 assert(isequaln(old.R.(f{1}),new.R.(f{1})),'Changed smoke result: %s',f{1});
end
for id=1:5
 name=sprintf('job_%05d.mat',id);
 old=load(fullfile(donor,'validation','accuracy_R1',name),'R');
 new=load(fullfile(S.accuracyDir,name),'R');
 assert(strcmp(new.R.snapshot,snapshot));
 assert(strcmp(new.R.importedFromSnapshot,old.R.snapshot));
 new.R=rmfield(new.R,'importedFromSnapshot');new.R.snapshot=old.R.snapshot;
 assert(isequaln(old.R,new.R),'Accuracy output changed.');
end
blocked=false;
try
 import_v57_B999_progress(donor,'all','smoke');
catch ME
 blocked=contains(ME.message,'Import before creating target accuracy results');
end
assert(blocked,'Importer must not overwrite existing results.');
fprintf('PASS: B399 settings, identical rebuilt smoke estimates/intervals/draws, unchanged accuracy, overwrite guard.\n');
end
