function verify_smoke(root)
addpath(root,fullfile(root,'src'));
[~,~,~,S]=prepare_v57_simulations('smoke');folder=fullfile(S.coverageDir,'rep_0001');
file=fullfile(folder,'Results.mat');L=load(file,'R');R=L.R;
assert(all(R.success));assert(all(R.validDraws([1 2],:)==19,'all') && all(R.validDraws(4,[1 2 4])==19));
for m=[1 2 4]
 keep=1:4;if m==4,keep=[1 2 4];end
 for k=keep
  d=R.draws{m}(:,k);d=d(isfinite(d));
  if m==1
   lo=R.point(m,k)-prctile(d,95);hi=R.point(m,k)-prctile(d,5);
  elseif m==2
   q=interp1(1:numel(d),sort(d),1+(numel(d)-1)*[.05,.95]);lo=q(1);hi=q(2);
  else
   q=prctile(d,[5 95]);lo=q(1);hi=q(2);
  end
  assert(max(abs([lo hi]-[R.low(m,k) R.high(m,k)]))<1e-10,'Interval reconstruction failed.');
 end
end
assert(R.point(4,3)==0 && all(isnan([R.low(4,3),R.high(4,3)])));
fprintf('PASS: paired coverage, all valid draws, interval reconstruction, structural changepoint target.\n');
% Rerun finished accuracy at a different worker count without changing a file.
hashes=cell(1,5);for id=1:5,hashes{id}=simulation_file_sha256(fullfile(S.accuracyDir,sprintf('job_%05d.mat',id)));end
run_v57_simulation_ids('accuracy',1:5,1,'smoke');
for id=1:5,assert(strcmp(hashes{id},simulation_file_sha256(fullfile(S.accuracyDir,sprintf('job_%05d.mat',id)))));end
% Simulate interruption after 18 inner draws; recompute one draw with two workers.
draw=fullfile(folder,'ss_inner','draw_00001.mat');ref=load(draw);
backup=fullfile(root,'validation','resume_reference_draw.mat');copyfile(draw,backup);delete(draw);
original=R;R.success(1)=false;v57_atomic_save(file,R);
run_v57_coverage(1,1,2,'smoke');new=load(draw);L=load(file,'R');
assert(isequaln(ref,new),'Draw changed with worker count.');
assert(isequaln(original.draws,L.R.draws) && max(abs(original.point-L.R.point),[],'all')<1e-12);
assert(isequaln(original.low,L.R.low) && isequaln(original.high,L.R.high));
out=collect_v57_simulations(12,'smoke');assert(out.accuracyComplete&&out.coverageComplete);
fprintf('PASS: checkpoint recovery and deterministic draw after worker count 4 -> 2.\n');
end
