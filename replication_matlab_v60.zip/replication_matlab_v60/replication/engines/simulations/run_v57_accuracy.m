function run_v57_accuracy(arrayIndex,nArrays,nWorkers,mode)
if nargin<2,nArrays=12;end
if nargin<3,nWorkers=20;end
if nargin<4,mode='production';end
validateattributes(nArrays,{'numeric'},{'scalar','integer','positive'});
validateattributes(arrayIndex,{'numeric'},{'scalar','integer','>=',1,'<=',nArrays});
[~,~,~,S]=prepare_v57_simulations(mode);
run_v57_simulation_ids('accuracy',arrayIndex:nArrays:(5*S.accuracyR),nWorkers,mode);
end
