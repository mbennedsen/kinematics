clear; close all;
ARRAY_INDEX = 1;  % Run separate jobs with values 1, 2, ..., 11.
nWorkers = 20;   % Match the workers allocated to THIS job.
B = 1999;
% Works with this launcher in the package folder or one subfolder below it.
packageDir=fileparts(mfilename('fullpath'));
if ~isfile(fullfile(packageDir,'run_v56_uncertainty.m')),packageDir=fileparts(packageDir);end
addpath(packageDir);
run_v56_uncertainty(ARRAY_INDEX,B,nWorkers);
