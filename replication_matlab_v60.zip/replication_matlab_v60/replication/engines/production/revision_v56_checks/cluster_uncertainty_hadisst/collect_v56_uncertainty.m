function results=collect_v56_uncertainty(B,jobs)
if nargin<1,B=1999;end
if nargin<2,jobs=1:11;end
assert(all(ismember(jobs,1:11))&&numel(unique(jobs))==numel(jobs));
[root,snapshot,C]=prepare_v56_uncertainty;results=table();missing=[];
for jobIndex=jobs(:)'
 annual=jobIndex>6;d=jobIndex-6*annual;kind='monthly';if annual,kind='annual';end
 folder=fullfile(root,'results',kind,C.names{d});marker=fullfile(folder,sprintf('JobComplete_B%d.mat',B));
 if ~isfile(marker),missing(end+1)=jobIndex;continue;end %#ok<AGROW>
 L=load(marker);assert(strcmp(L.snapshot,snapshot)&&L.B==B&&L.jobIndex==jobIndex,'Job provenance mismatch.');
 for j=1:4
  file=fullfile(folder,sprintf('%s_B%d',L.allMethods{j},B),'Summary.csv');
  assert(strcmp(simulation_file_sha256(file),L.hashes{j}),'Summary changed after completion: %s',file);
  R=readtable(file,'TextType','string');assert(height(R)==4);results=[results;R]; %#ok<AGROW>
 end
end
if ~isempty(missing)
 fprintf('Missing/incomplete jobIndex values: %s\n',num2str(missing));
 error('v56:Incomplete','Wait for these jobs or rerun just their indices. No combined results written.');
end
file=fullfile(root,'results',sprintf('Combined_B%d_jobs_%s.csv',B,strjoin(string(jobs),'-')));
writetable(results,file);fprintf('PASS: %d jobs, %d method fits, %d result rows.\n%s\n',numel(jobs),4*numel(jobs),height(results),file);
end
