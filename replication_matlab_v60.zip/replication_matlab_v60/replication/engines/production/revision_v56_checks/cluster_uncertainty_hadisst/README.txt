V56 UNCERTAINTY REFRESH: CONSISTENT ORDINARY HADISST ENSO
======================================================

Copy/extract this ENTIRE folder to a NEW cluster directory. It is standalone.
Do not copy results from v55 or the earlier mixed-index input into this folder.
No data download, external project directory, or preparation fit is required.

QUICK START
Open MATLAB in this folder:

  prepare_v56_uncertainty

It should print PASS, with 6 monthly + 5 annual jobs. This is a read-only
integrity check, not a fitting job. It may safely run at the start of every job.

Submit ELEVEN separate MATLAB jobs with jobIndex = 1,2,...,11:

  run_v56_uncertainty(jobIndex,1999,20)

Or use the included run_analysis_1.m and change ARRAY_INDEX for each job:

  clear; close all;
  ARRAY_INDEX = 1;
  nWorkers = 20;
  B = 1999;
  run_v56_uncertainty(ARRAY_INDEX,B,nWorkers);

20 means workers for EACH job; match the allocation provided by your cluster.
These indices identify records, not replication chunks. There is no nArrays
argument. Different jobs can use different worker counts. Do not run duplicate
jobs for the same index/B/output folder concurrently. Your launcher can be in
the package folder or one subfolder below it (the included launcher handles
both); launchers are not included in the scientific source hashes.

 JOB   FREQUENCY   RECORD
  1    monthly    NASA
  2    monthly    NOAA
  3    monthly    HadCRUT5 (internal name HadCRU)
  4    monthly    Berkeley Earth (Berk)
  5    monthly    ERA5
  6    monthly    Arithmetic-mean temperature series (Mean)
  7    annual     NASA
  8    annual     NOAA
  9    annual     HadCRUT5
 10    annual     Berkeley Earth
 11    annual     ERA5

All eleven jobs can be launched together. The annual jobs do NOT need to wait
for monthly bootstraps: their fixed monthly smoothing parameters are already
frozen from the verified corrected-input monthly point fits.

Each job runs quadratic, full-search changepoint, nonparametric, then
state-space inference. Bootstrap methods use 1,999 draws; quadratic inference
uses HAC standard errors. Output folders contain B1999 also for quadratic to
keep the whole run together; its Summary.csv correctly reports BootstrapB=0.

COLLECT AND RETURN
After all eleven jobs finish:

  collect_v56_uncertainty(1999)

This verifies all completion markers and prints any missing job indices.
To collect only the monthly results after jobs 1--6 finish:

  collect_v56_uncertainty(1999,1:6)

Copy back the ENTIRE results folder, preserving all MAT files and subfolders.
CSV summaries suffice for a first numerical check; MAT files are needed for
paths, figures, diagnostics, covariate effects and supplementary results.

The combined file is results/Combined_B1999_jobs_1-2-3-4-5-6-7-8-9-10-11.csv.
Expected complete release: 11 jobs, 44 method fits, 176 endpoint-summary rows.
Each job's results/<frequency>/<record>/<method>_B1999/Summary.csv reports
level, rate, endpoint acceleration and past-decade average acceleration.
Monthly SS additionally retains full pointwise path bands and paired velocity
errors; changepoint results retain breakpoint and coefficient draws/windows.

RESUMING / WORKER COUNTS
Rerun the same command for an incomplete job. Completed method fits are reused
after moving the package or changing nWorkers; their original provenance is
retained. Worker settings and output paths are excluded from cache comparisons.

Monthly state-space inference retains the existing whole-fit bootstrap code:
an interrupted monthly SS fit restarts that record's unfinished bootstrap.
It does NOT resume individual monthly draws. The original parallel RNG behavior
is preserved; a fresh run with a different pool size need not reproduce the
same Monte Carlo draws. Completed fits can still be reused without alteration.

Annual SS saves every 100 draws and resumes those checkpoints. Its seeds are
indexed by dataset/draw, independently of worker count. Completed failures are
retained; fewer than 95% usable draws causes a diagnostic stop. The monthly SS
and nonparametric output checks also require at least 95% usable draws.

Changed data, scientific options, or engine code must use a newly prepared
package/output. Do not disable the hash checks or regenerate the manifest to
force incompatible results together. Editing run_analysis_1.m is fine.

SMALL CHECKS (NOT SCIENTIFIC INFERENCE)
One monthly SS check, three draws, two workers:
  run_v56_uncertainty(5,3,2,{'ss'})
One annual SS check:
  run_v56_uncertainty(11,3,1,{'ss'})
All four methods for a small annual check (changepoint requires B>=19):
  run_v56_uncertainty(11,19,1)
These write B3/B19 folders separately from the scientific B1999 release.

SCIENTIFIC SPECIFICATION
This uses the corrected ORDINARY HadISST Niño 3.4 index, NOT the relative-ENSO
sensitivity index. The temperature vintage is unchanged (July/August 2026),
and the monthly covariates through 2024 are unchanged. Only the ordinary ENSO
extension from January 2025 onward is replaced by the source-consistent series.
Annual ENSO retains the September--August exposure convention; only the 2025
annual ENSO value changes. Annual temperatures have been translated to a
1991--2020 mean of 0.88 deg C and all annual estimators disable further rebasing.

Monthly SS: the original posteriorResidual/bootstrapError procedure, with
parameter re-estimation, ARMA(1,1) irregular variation, calendar-month-specific
innovation variance, and 90% basic intervals. Past-decade acceleration is the
paired 120-month velocity contrast from each same fitted/true path. The same
paired errors supply alternative start-date intervals. No marginal bands are
differenced. The state-space estimator/helper files are frozen unchanged copies.

Annual SS: fixed at the corrected monthly diffusion variance for each record;
other parameters are refitted in the existing posterior-residual bootstrap.
AR(1) errors for NASA/NOAA/HadCRUT5/Berkeley; IID for ERA5, preserving the annual
SS specification. Annual intervals remain conditional on monthly sigma.
The averaging window is 2015--2025, the final decade of the annual sample.

Nonparametric: existing 25-year bandwidth, covariate refitting and moving-block
bootstrap; monthly 24-month and annual two-observation blocks. Quadratic:
existing sample windows and HAC settings. Changepoint: ALL regression
coefficients and the breakpoint are re-estimated on every draw; monthly noise
is ARMA(1,1), annual noise AR(1). Conditional-on-selected-break HAC output in
the changepoint 'point' subfolder is intermediate only. Use the parent
Summary.csv with full-search bootstrap intervals for reported inference.
Endpoint changepoint acceleration is structural zero and has no interval.
Annual break-search restrictions can force past-decade contrasts to zero.

No no-covariate rerun is needed for this index change. No simulation/null-study
input or output is changed. The package does not edit the manuscript or website.

REQUIREMENTS
MATLAB with the Statistics and Machine Learning Toolbox (prctile), preferably
Optimization Toolbox (the monthly production code uses fminunc when available),
and Parallel Computing Toolbox for nWorkers>1. Tested locally using R2025b.
For replication of the production optimizer, use the same available toolboxes
as the earlier monthly bootstrap jobs. No Python or internet is needed on the
cluster. Configuration.mat and SHA256SUMS.tsv are frozen package inputs.
