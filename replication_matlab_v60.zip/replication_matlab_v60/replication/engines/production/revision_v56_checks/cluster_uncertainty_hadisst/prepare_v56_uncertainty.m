function [root,snapshot,C]=prepare_v56_uncertainty
% Read-only preflight. Never regenerates inputs or hashes user launch scripts.
root=fileparts(mfilename('fullpath'));addpath(root,fullfile(root,'src'));
manifest=fullfile(root,'SHA256SUMS.tsv');assert(isfile(manifest),'Package manifest is missing.');
fid=fopen(manifest,'r');clean=onCleanup(@()fclose(fid));rows=textscan(fid,'%s%s','Delimiter','\t');
for j=1:numel(rows{1})
 file=fullfile(root,rows{2}{j});assert(isfile(file),'Package file missing: %s',file);
 assert(strcmp(simulation_file_sha256(file),rows{1}{j}), ...
  'Package input/code changed: %s. Preserve results; use a newly prepared package.',rows{2}{j});
end
snapshot=simulation_file_sha256(manifest);L=load(fullfile(root,'Configuration.mat'),'C');C=L.C;
M=readtable(fullfile(root,'Data','Monthly_HadISST.csv'));A=readtable(fullfile(root,'Data','Annual_HadISST.csv'));
assert(max(abs(diff(M.t)-1/12))<1e-8 && all(diff(A.year)==1) && A.year(end)==2025);
for j=1:5
 name=C.names{j};assert(abs(mean(A.(name)(A.year>=1991 & A.year<=2020))-.88)<1e-12);
 assert(~C.annual.(name).ss.rebaseData);
 assert(C.annual.(name).ss.stateSpace.fixedQ==C.monthly.(name).fixedQReference);
end
assert(contains(C.indexConvention,'Ordinary HadISST'));
fprintf('PASS: verified %d frozen files; consistent ordinary HadISST ENSO; 6 monthly + 5 annual jobs.\n',numel(rows{1}));
end
