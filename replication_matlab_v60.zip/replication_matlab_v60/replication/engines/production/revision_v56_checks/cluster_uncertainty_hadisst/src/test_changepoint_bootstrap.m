function test_changepoint_bootstrap()
here=fileparts(mfilename('fullpath'));addpath(here);rng(771);
% Profile likelihood must equal the dense stationary Gaussian covariance.
u=randn(25,1);phi=.71;theta=-.28;
g0=(1+theta^2+2*phi*theta)/(1-phi^2);g1=phi*g0+theta;g=[g0,g1*phi.^(0:23)];C=toeplitz(g);
s2=(u'*(C\u))/numel(u);expected=.5*(numel(u)*(log(2*pi)+1+log(s2))+2*sum(log(diag(chol(C)))));
[actual,v]=arma11_profile_nll(u,phi,theta);assert(abs(actual-expected)<1e-10 && abs(v-s2)<1e-10);
ar=fit_ar1_bootstrap_noise(u);assert(ar.theta==0 && ar.optimizerExitFlag>0);
% Exact stationary simulation and stream independence of requested draw count.
noise=struct('phi',phi,'theta',theta,'innovationVariance',.07);
a=simulate_arma11_stationary(noise,100,[10 11]);b=simulate_arma11_stationary(noise,100,10);assert(isequal(a(:,1),b));
% Search with covariates: agreement with brute-force least squares on each draw.
t=(1970:1/12:2026)';Z=[sin(t),cos(t/3)];dates=t(61:end-60);Y=.02*t+.03*max(t-2014,0)+Z*[.1;.2]+randn(numel(t),4)*.1;
f=fit_broken_trend_grid(t,Z,Y,dates);s=t-mean(t);
for k=1:4
 sse=nan(numel(dates),1);coeff=cell(numel(dates),1);
 for j=1:numel(dates),X=[ones(numel(t),1),s,max(t-dates(j),0),Z];coeff{j}=X\Y(:,k);sse(j)=sum((Y(:,k)-X*coeff{j}).^2);end
 [~,j]=min(sse);assert(f.breakDate(k)==dates(j) && max(abs(f.coeff(:,k)-coeff{j}))<1e-9);
end
% A break within the averaging window contributes a nonzero rate contrast;
% a break before it contributes exactly zero, although endpoint a is always zero.
assert(100*.02*(double(2026>=2018)-double(2016>=2018))/10==.2);
assert(100*.02*(double(2026>=2014)-double(2016>=2014))/10==0);
assert(100*.02*(double(2026>=2016)-double(2016>=2016))/10==0);
fprintf('PASS: exact ARMA likelihood, deterministic stationary draws, full-grid regression equivalence and average-acceleration contrast.\n');
end
