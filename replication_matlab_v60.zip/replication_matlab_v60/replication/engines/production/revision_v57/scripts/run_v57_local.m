function run_v57_local
base=fileparts(fileparts(mfilename('fullpath')));root=fileparts(base);addpath(fullfile(base,'scripts'),root,fullfile(root,'revision_v55','scripts'));
p=parpool('local',5);
parfor d=1:5
 run_v57_robustness(d,base);run_v57_kernel_windows(d,base);
end
delete(p);
end
