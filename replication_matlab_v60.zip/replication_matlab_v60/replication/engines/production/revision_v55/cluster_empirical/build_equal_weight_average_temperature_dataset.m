function [augmented, info] = build_equal_weight_average_temperature_dataset(dataFile, outputFile, userOpts)
% BUILD_EQUAL_WEIGHT_AVERAGE_TEMPERATURE_DATASET
% Add an equal-weight mean of the temperature records on a common baseline.
%
% By default, the series is the equal-weight average of NASA, NOAA, HadCRU,
% and Berkeley Earth before ERA5 begins, and the equal-weight average of all
% five records thereafter.  The source records are first translated to the
% common 1991--2020 mean of 0.88 degC.  This is essential when composition
% changes: averaging native anomaly scales could otherwise create an
% artificial level shift when ERA5 enters.
%
% Example:
%   build_equal_weight_average_temperature_dataset( ...
%       fullfile('Data','ObservedData.csv'), ...
%       fullfile('results_average_dataset','ObservedData_with_Average.csv'));

    if nargin < 1 || isempty(dataFile)
        dataFile = fullfile('Data', 'ObservedData.csv');
    end
    if nargin < 2
        outputFile = '';
    end
    if nargin < 3
        userOpts = struct();
    end

    opts = struct();
    opts.sourceDatasets = {'NASA','NOAA','HadCRU','Berk','ERA5'};
    opts.averageName = 'Average';
    opts.compositionMode = 'fourThenFive';
    opts.lateDataset = 'ERA5';
    opts.rebaseBeforeAveraging = true;
    opts.rebaseTargetMean = 0.88;
    opts.rebaseStartYear = 1991;
    opts.rebaseEndYear = 2021;
    opts = merge_structs_local(opts, userOpts);

    assert(exist(dataFile, 'file') == 2, 'Data file not found: %s', dataFile);
    augmented = readtable(dataFile, 'VariableNamingRule', 'preserve');

    values = nan(height(augmented), numel(opts.sourceDatasets));
    for d = 1:numel(opts.sourceDatasets)
        name = opts.sourceDatasets{d};
        assert(ismember(name, augmented.Properties.VariableNames), ...
            'Missing source dataset column %s in %s.', name, dataFile);
        values(:, d) = coerce_numeric_local(augmented.(name));
    end

    t = coerce_numeric_local(augmented.t);
    if opts.rebaseBeforeAveraging
        ref = t >= opts.rebaseStartYear & t < opts.rebaseEndYear;
        for d = 1:size(values, 2)
            mu = mean(values(ref, d), 'omitnan');
            assert(isfinite(mu), 'No reference-period observations for %s.', ...
                opts.sourceDatasets{d});
            values(:, d) = values(:, d) + (opts.rebaseTargetMean - mu);
        end
    end

    average = nan(height(augmented), 1);
    nContributors = zeros(height(augmented), 1);
    switch lower(strtrim(opts.compositionMode))
        case {'fourthenfive','four_then_five'}
            lateIdx = find(strcmp(opts.sourceDatasets, opts.lateDataset), 1);
            assert(~isempty(lateIdx), 'Late dataset %s is not in sourceDatasets.', opts.lateDataset);
            lateFirst = find(isfinite(values(:, lateIdx)), 1, 'first');
            assert(~isempty(lateFirst), 'Late dataset %s contains no finite values.', opts.lateDataset);

            earlyIdx = setdiff(1:numel(opts.sourceDatasets), lateIdx, 'stable');
            earlyRows = (1:height(augmented))' < lateFirst;
            earlyComplete = earlyRows & all(isfinite(values(:, earlyIdx)), 2);
            average(earlyComplete) = mean(values(earlyComplete, earlyIdx), 2);
            nContributors(earlyComplete) = numel(earlyIdx);

            lateRows = (1:height(augmented))' >= lateFirst;
            lateComplete = lateRows & all(isfinite(values), 2);
            average(lateComplete) = mean(values(lateComplete, :), 2);
            nContributors(lateComplete) = numel(opts.sourceDatasets);
        case {'allfive','all_five'}
            complete = all(isfinite(values), 2);
            average(complete) = mean(values(complete, :), 2);
            nContributors(complete) = numel(opts.sourceDatasets);
        otherwise
            error('Unknown compositionMode: %s', opts.compositionMode);
    end

    augmented.(opts.averageName) = average;

    finiteRows = find(isfinite(average) & isfinite(t));
    assert(~isempty(finiteRows), 'The constructed average contains no finite observations.');

    info = struct();
    info.dataFile = dataFile;
    info.outputFile = outputFile;
    info.sourceDatasets = opts.sourceDatasets;
    info.averageName = opts.averageName;
    info.compositionMode = opts.compositionMode;
    info.lateDataset = opts.lateDataset;
    info.rebaseBeforeAveraging = opts.rebaseBeforeAveraging;
    info.rebaseTargetMean = opts.rebaseTargetMean;
    info.nFinite = numel(finiteRows);
    info.firstTime = t(finiteRows(1));
    info.lastTime = t(finiteRows(end));
    info.weights = repmat(1 / numel(opts.sourceDatasets), 1, numel(opts.sourceDatasets));
    info.nFourRecordMonths = sum(nContributors == 4);
    info.nFiveRecordMonths = sum(nContributors == 5);
    info.nContributors = nContributors;

    if ~isempty(outputFile)
        outputDir = fileparts(outputFile);
        if ~isempty(outputDir) && ~exist(outputDir, 'dir')
            mkdir(outputDir);
        end
        writetable(augmented, outputFile);
        fprintf(['Created %s as a common-baseline equal-weight mean of %s.\n', ...
            'Four-record months: %d; five-record months: %d.\n', ...
            'Finite observations: %d (%.4f--%.4f).\n', ...
            'Saved augmented data to:\n  %s\n'], ...
            opts.averageName, strjoin(opts.sourceDatasets, ', '), ...
            info.nFourRecordMonths, info.nFiveRecordMonths, ...
            info.nFinite, info.firstTime, info.lastTime, outputFile);
    end
end

%% ========================================================================
function x = coerce_numeric_local(x)

    if isnumeric(x)
        x = x(:);
    elseif islogical(x)
        x = double(x(:));
    else
        x = str2double(string(x));
        x = x(:);
    end
end

%% ========================================================================
function out = merge_structs_local(base, update)

    out = base;
    if isempty(update)
        return;
    end
    fields = fieldnames(update);
    for i = 1:numel(fields)
        name = fields{i};
        if isstruct(update.(name)) && isfield(out, name) && isstruct(out.(name))
            out.(name) = merge_structs_local(out.(name), update.(name));
        else
            out.(name) = update.(name);
        end
    end
end
