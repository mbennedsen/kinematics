function summary=run_v55_empirical(jobIndex,B,nWorkers,methods)
% Jobs 1:6 adjusted; 7:12 without controls. Default: SS only for cluster work.
% Explicit methods may include benchmarks; B governs SS, kernel always B=1999.
if nargin<2,B=1999;end
if nargin<3,nWorkers=20;end
if nargin<4,methods={'ss'};end
validateattributes(jobIndex,{'numeric'},{'scalar','integer','>=',1,'<=',12});
root=fileparts(mfilename('fullpath'));addpath(root);
old=pwd;clean=onCleanup(@()cd(old));cd(root);
noCov=jobIndex>6;d=mod(jobIndex-1,6)+1;names={'NASA','NOAA','HadCRU','Berk','ERA5','Mean'};name=names{d};
if noCov,kind='no_covariates';input=fullfile(root,'Data','ObservedData_no_covariates.csv');
else,kind='monthly';input=fullfile(root,'Data','ObservedData_with_Mean.csv');end
assert(isfile(input),'Run prepare_v55_empirical once before starting jobs.');
raw=readtable(input); ix=find(isfinite(raw.(name)));T0=raw.t(ix(end)-120);
common=struct('datasets',{{name}},'seed',550000+jobIndex,'rebaseData',true);
if noCov,common.covariates=struct('names',{{}},'maxLags',[],'almonDegrees',[],'standardize',false,'includeMonthlyDummies',false);end
summary=table();
for m=1:numel(methods)
 method=methods{m};o=common;draws=0;
 switch method
  case 'quadratic'
   if noCov,fun=@estimate_quadratic_no_covariates;else,fun=@estimate_quadratic_benchmark;end
   o.quadratic=struct('windowStartYear',1970,'trailingMonths',60,'hacLagMonths',24);o.inference=struct('ciLevel',.9);
  case 'changepoint'
   if noCov,fun=@estimate_changepoint_no_covariates;else,fun=@estimate_broken_trend_benchmark;end
   o.broken=struct('windowStartYear',1970,'trailingMonths',60,'hacLagMonths',24,'minSegmentMonths',60,'candidateStepMonths',1);o.inference=struct('ciLevel',.9);
  case 'kernel'
   if noCov,fun=@estimate_kernel_no_covariates;else,fun=@estimate_kernel_benchmark_v3;end
   draws=1999;o.kernel=struct('bandwidthYears',25,'averageStartYear',T0,'trailingMonths',60);
   o.bootstrap=struct('B',draws,'ciAlpha',.1,'blockLengthMonths',24,'useParallel',false,'verboseEvery',0);
  case 'ss'
   if noCov,fun=@estimate_ss_no_covariates;else,fun=@estimate_ss_individual_tables_bootstrap_v4;end
   if B>2
    if noCov,fun=@estimate_ss_v55_no_covariates_keep_velocity;else,fun=@estimate_ss_v55_keep_velocity;end
   end
   draws=B;o.averageAcceleration=struct('enabled',true,'T0',2015);
   o.bootstrap=struct('B',B,'ciAlpha',.1,'useParallel',nWorkers>1,'nWorkers',nWorkers, ...
    'pathBands',true,'method','posteriorResidual','inferenceMode','bootstrapError', ...
    'includeParameterUncertainty',true,'startAtOriginalTheta',true,'maxRefitTries',2);
  otherwise,error('Unknown method');
 end
 folder=fullfile(root,'results',kind,name,sprintf('%s_B%d',method,draws));if ~isfolder(folder),mkdir(folder);end
 o.outputDir=folder;
 key=struct('inputSHA',simulation_file_sha256(input),'options',o,'sourceSHA',simulation_file_sha256(which(func2str(fun))));
 if strcmp(method,'ss') && B>2,key.pathHelperSHA=simulation_file_sha256(fullfile(root,'summarize_kinematic_path_errors_keep_velocity.m'));end
 file=fullfile(folder,'CompletedFit.mat');
 if isfile(file)
  L=load(file,'key','fit');
  [compatible,differences]=v55_empirical_cache_compatible(key,L.key);
  if ~compatible
   error('v55:CacheMismatch','Cache mismatch for %s/%s (%s).\nFile: %s\nDiffering fields:\n%s\nPreserve the existing output; do not disable this check.', ...
    kind,name,method,file,strjoin(differences,newline));
  end
  fit=L.fit;
  fprintf('Reusing completed %s/%s/%s B=%d (original fit provenance retained).\n',kind,name,method,draws);
 else
  fprintf('v55 %s / %s / %s / B=%d\n',kind,name,method,draws);started=tic;
  captured=evalc('fit=fun(input,o);');seconds=toc(started);
  fid=fopen(fullfile(folder,'Estimation.log'),'w');fprintf(fid,'%s',captured);fclose(fid);
  save(file,'key','fit','seconds','-v7.3');fprintf('Completed %s/%s in %.1f seconds\n',name,method,seconds);
 end
 E=fit.detail.(name);
 if strcmp(method,'ss')
  assert(E.pointEstimate.exitflag>0,'Outer optimizer did not converge.');
  if noCov,assert(isempty(E.pointEstimate.paramsHat.beta));end
 end
 if strcmp(method,'ss') && B>2, v55_velocity_window_intervals(E,name,folder);end
 R=v55_empirical_rows(name,method,E,draws);R.Specification=repmat(string(kind),4,1);
 writetable(R,fullfile(folder,'Summary.csv'));summary=[summary;R]; %#ok<AGROW>
end
end
