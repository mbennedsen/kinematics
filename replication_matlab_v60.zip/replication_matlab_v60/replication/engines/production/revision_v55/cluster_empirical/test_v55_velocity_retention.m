function test_v55_velocity_retention()
% Extra retained draws must not alter any interval; shared rate errors cancel.
rng(55);T=160;B=25;alpha=randn(3,T);errors=randn(T,4,B);
errors(1:120,4,:)=NaN;
for b=1:B
 errors(121:end,4,b)=errors(121:end,2,b)-errors(1:end-120,2,b);
end
old=summarize_kinematic_path_errors(alpha,errors,.1);
new=summarize_kinematic_path_errors_keep_velocity(alpha,errors,.1);
assert(isequaln(old.low,new.low)&&isequaln(old.high,new.high));
assert(isequal(new.velocityErrors,reshape(errors(:,2,:),T,B)));
v=kinematic_path_values(alpha);ci=v(end,4)-prctile(new.velocityErrors(end,:)-new.velocityErrors(end-120,:),[95 5]);
assert(max(abs(ci-[new.low(end,4),new.high(end,4)]))<1e-12);
% An identical error at every date cancels exactly from the contrast.
common=reshape(randn(1,B),1,1,B);errors(:,2,:)=repmat(common,T,1,1);errors(121:end,4,:)=0;
new=summarize_kinematic_path_errors_keep_velocity(alpha,errors,.1);
assert(new.low(end,4)==v(end,4)&&new.high(end,4)==v(end,4));
fprintf('PASS: retained velocity errors leave bands unchanged and preserve paired dependence.\n');
end
