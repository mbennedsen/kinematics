V55 -- CORRECTED MONTHLY EMPIRICAL INFERENCE
==========================================

This is a NEW study. Do not merge results from the earlier website input or
from the original null-validation package. The website temperature vintage is
retained (July/August 2026 endpoints), but its covariate alignment is corrected.
The package contains the corrected data and the prepared mean/no-control inputs.

Run prepare_v55_empirical ONCE before launching jobs. It verifies existing
prepared inputs silently except for a success message; it does not fit models.

Then submit jobIndex = 1,...,12, with 20 workers allocated per job:

    run_v55_empirical(jobIndex,1999,20,{'ss'});

Jobs 1--6: NASA, NOAA, HadCRU, Berk, ERA5, Mean, WITH climate controls.
Jobs 7--12: same order, WITHOUT climate controls.
This is 12 independent jobs, not 32 chunks. nWorkers is the third argument.
Custom launchers can be in this folder or a subfolder; they are not hashed as
scientific dependencies. If in a subfolder, add its parent to the MATLAB path.

An optional two-draw check (NOT scientific inference):
    run_v55_empirical(1,2,1,{'ss'});

The output directories distinguish B=0 point fits and B=2/3 checks from B=1999.
Finished method fits are cached against input, specification and estimator hash.
An interrupted B=1999 fit restarts that record's bootstrap. Different records
are independent jobs. Do not run duplicate jobs for one record/specification.
Completed whole-fit caches may be reused after moving the package or changing
worker settings. Their original saved key/options are retained as provenance.
Input hashes, estimator/helper hashes, seed and scientific options must match;
an incompatible cache now reports the specific differing fields and file.
The three-argument call run_v55_empirical(jobIndex,B,nWorkers) defaults to SS
only. To request all four explicitly, pass {'quadratic','changepoint','kernel','ss'}.

Target and method
-----------------
Primary average acceleration is [v(T)-v(T-10 years)]/(10 years), using a
120-month lag. Every contrast uses both rates from the SAME fitted/true path.
The monthly data dates have exact monthly midpoints. The arithmetic mean is
four products before 1940 and five thereafter, requiring all relevant records.
The no-control sample retains the original 12-lag alignment.

Inference is the existing posteriorResidual/bootstrapError procedure, with
all parameters refitted, nominal 90% two-sided basic intervals, original starts
and retry settings. The B>2 estimator copies differ from production ONLY in
function names and retaining velocity-path errors in the path summary. Fitting,
simulation, interval arithmetic and optimizer acceptance rules are unchanged.
These retained paired errors supply the ten-year and alternative-start intervals
without further refits. Raw errors are retained for future window changes.

Return results/monthly and results/no_covariates. Each record's ss_B1999 folder
contains Summary.csv, AverageAcceleration_Windows.csv, CompletedFit.mat and the
production SS_Table_Bootstrap_Output.mat. Keep full MAT files as provenance.
For initial inspection the two CSVs per record suffice; full MAT files also
supply paths, diagnostics, covariate coefficients and supplementary tables.

The nonparametric and parametric models are being run locally, so the {'ss'}
argument avoids repeating those inexpensive calculations on the cluster.
The same corrected fitted objects can later supply an updated website; this
package does not publish or change the public website.
