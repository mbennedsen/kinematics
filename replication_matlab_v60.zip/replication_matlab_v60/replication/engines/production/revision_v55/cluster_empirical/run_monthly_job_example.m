% One cluster job; edit jobIndex only. See README.txt for the 1:12 mapping.
root=fileparts(mfilename('fullpath'));addpath(root);
jobIndex=1;nWorkers=20;
run_v55_empirical(jobIndex,1999,nWorkers,{'ss'});
