function prepare_v55_empirical()
root=fileparts(mfilename('fullpath')); addpath(root);
source=fullfile(root,'Data','ObservedData.csv');
[T,~]=build_equal_weight_average_temperature_dataset(source,'',struct('averageName','Mean'));
assert(all(abs(diff(T.t)-1/12)<1e-8));
files={'ObservedData_with_Mean.csv','ObservedData_no_covariates.csv'};
valid=true(height(T),1);
for c={'NINO34','volc2','ssn'}
 x=T.(c{1}); for lag=0:12, valid=valid & [false(lag,1);isfinite(x(1:end-lag))]; end
end
N=T; names={'NASA','NOAA','HadCRU','Berk','ERA5','Mean'};
for d=1:6, N.(names{d})(~valid)=NaN; end
N=N(:,[{'t'},names]);
for i=1:2
 file=fullfile(root,'Data',files{i});if i==1, expected=T;else,expected=N;end
 if isfile(file)
  got=readtable(file);assert(isequal(got.Properties.VariableNames,expected.Properties.VariableNames));
  a=got{:,:};b=expected{:,:};assert(isequal(isnan(a),isnan(b)));assert(max(abs(a(:)-b(:)),[],'omitnan')<1e-10,'Prepared data changed.');
 else,writetable(expected,file);end
end
fprintf('Prepared corrected v55 inputs. All monthly intervals are exactly 1/12 year.\n');
end
