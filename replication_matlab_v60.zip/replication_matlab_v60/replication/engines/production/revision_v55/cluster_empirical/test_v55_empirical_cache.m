function test_v55_empirical_cache()
% Check relocation of real completed point/bootstrap fits without refitting.
root=fileparts(mfilename('fullpath'));
L=load(fullfile(root,'results','monthly','NASA','ss_B0','CompletedFit.mat'),'key');
saved=L.key;requested=saved;requested.options.outputDir='/different/cluster/output';
requested.options.bootstrap.nWorkers=7;requested.options.bootstrap.useParallel=true;
assert(v55_empirical_cache_compatible(requested,saved));
bad=requested;bad.inputSHA='changed';[ok,d]=v55_empirical_cache_compatible(bad,saved);assert(~ok&&contains(d{1},'inputSHA'));
bad=requested;bad.sourceSHA='changed';assert(~v55_empirical_cache_compatible(bad,saved));
bad=requested;bad.options.seed=bad.options.seed+1;assert(~v55_empirical_cache_compatible(bad,saved));
bad=requested;bad.options.bootstrap.B=1999;assert(~v55_empirical_cache_compatible(bad,saved));
bad=requested;bad.options.bootstrap.ciAlpha=.05;assert(~v55_empirical_cache_compatible(bad,saved));
bad=requested;bad.pathHelperSHA='new dependency';assert(~v55_empirical_cache_compatible(bad,saved));
destination=tempname;mkdir(destination);previous=pwd;
cleanup=onCleanup(@()restore_and_remove(previous,destination));
files=dir(fullfile(root,'*.m'));for i=1:numel(files),copyfile(fullfile(root,files(i).name),destination);end
copyfile(fullfile(root,'Data'),fullfile(destination,'Data'));
for B=[0 3]
 source=fullfile(root,'results','monthly','NASA',sprintf('ss_B%d',B),'CompletedFit.mat');
 folder=fullfile(destination,'results','monthly','NASA',sprintf('ss_B%d',B));mkdir(folder);copyfile(source,folder);
end
cd(destination);
for B=[0 3]
 file=fullfile(destination,'results','monthly','NASA',sprintf('ss_B%d',B),'CompletedFit.mat');
 before=simulation_file_sha256(file);started=tic;
 rows=run_v55_empirical(1,B,7); % Three arguments must select only SS.
 assert(height(rows)==4&&all(rows.Method=="ss"));
 assert(strcmp(before,simulation_file_sha256(file)),'Saved provenance changed.');
 fprintf('PASS: relocated SS B=%d cache reused in %.2f seconds without modifying CompletedFit.mat.\n',B,toc(started));
end
fprintf('PASS: data/code/seed/B/interval-level/dependency changes remain rejected.\n');
end

function restore_and_remove(previous,destination)
cd(previous);rmpath(destination);rmdir(destination,'s');
end
