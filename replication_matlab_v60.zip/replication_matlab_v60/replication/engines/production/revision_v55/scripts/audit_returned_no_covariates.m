function audit_returned_no_covariates()
base=fileparts(fileparts(mfilename('fullpath')));bundle=fullfile(base,'cluster_empirical');addpath(bundle);
out=fullfile(base,'validated_no_covariates');if ~isfolder(out),mkdir(out);end
names={'NASA','NOAA','HadCRU','Berk','ERA5','Mean'};audit=table();allWindows=table();detail=struct();
for d=1:6
 name=names{d};folder=fullfile(bundle,'results','no_covariates',name,'ss_B1999');
 L=load(fullfile(folder,'CompletedFit.mat'),'key','fit');
 P=load(fullfile(bundle,'results','no_covariates',name,'ss_B0','CompletedFit.mat'),'key','fit');
 expected=P.key;expected.options.bootstrap.B=1999;
 expected.sourceSHA=simulation_file_sha256(fullfile(bundle,'estimate_ss_v55_no_covariates_keep_velocity.m'));
 expected.pathHelperSHA=simulation_file_sha256(fullfile(bundle,'summarize_kinematic_path_errors_keep_velocity.m'));
 [ok,difference]=v55_empirical_cache_compatible(expected,L.key);assert(ok,strjoin(difference,newline));
 assert(strcmp(L.key.inputSHA,simulation_file_sha256(fullfile(bundle,'Data','ObservedData_no_covariates.csv'))));
 E=L.fit.detail.(name);assert(isempty(E.pointEstimate.paramsHat.beta),'Unexpected covariate coefficients.');B=E.bootstrap;T=E.sampleData.t;z=kinematic_path_values(E.pointEstimate.smoother.alphaSmooth);
 assert(E.pointEstimate.exitflag>0&&B.pathBands.requestedDraws==1999&&B.pathBands.validDraws==1999);
 assert(all(B.pathBands.validPathDraws)&&size(B.pathBands.velocityErrors,2)==1999);
 assert(max(abs(T-P.fit.detail.(name).sampleData.t))<1e-10&&abs(T(end)-T(end-120)-10)<1e-10);
 z0=kinematic_path_values(P.fit.detail.(name).pointEstimate.smoother.alphaSmooth);
 delta=max(abs(z(end,:)-z0(end,:)));assert(delta<1e-4,'Point fits differ materially.');
 maxError=0;fields={'position','velocity','acceleration'};
 for j=1:3
  errors=B.replicates.(fields{j});assert(isequal(size(errors),[1999 2])&&all(isfinite(errors),'all'));
  ci=z(end,j)-prctile(errors(:,1),[95 5]);
  reported=[B.(fields{j}).endpoint_ci_low,B.(fields{j}).endpoint_ci_high];
  maxError=max([maxError,max(abs(ci-reported)),max(abs(ci-[B.pathBands.low(end,j),B.pathBands.high(end,j)]))]);
 end
 errors=B.pathBands.velocityErrors(end,:)-B.pathBands.velocityErrors(end-120,:);
 ci=z(end,4)-prctile(errors,[95 5]);maxError=max(maxError,max(abs(ci-[B.pathBands.low(end,4),B.pathBands.high(end,4)])));
 assert(maxError<1e-9,'Bootstrap quantiles do not reconstruct intervals.');
 R=v55_empirical_rows(name,'ss',E,1999);saved=readtable(fullfile(folder,'Summary.csv'));
 assert(max(abs(R{:,{'Estimate','CILow','CIHigh'}}-saved{:,{'Estimate','CILow','CIHigh'}}),[],'all')<1e-10);
 W=v55_velocity_window_intervals(E,name,out);old=readtable(fullfile(folder,'AverageAcceleration_Windows.csv'));
 assert(max(abs(W{:,{'Estimate','CILow','CIHigh'}}-old{:,{'Estimate','CILow','CIHigh'}}),[],'all')<1e-9);
 Writetable=table(T,E.sampleData.y,z(:,1),z(:,2),z(:,3),z(:,4), ...
  B.pathBands.low(:,1),B.pathBands.high(:,1),B.pathBands.low(:,2),B.pathBands.high(:,2), ...
  B.pathBands.low(:,3),B.pathBands.high(:,3),'VariableNames',{'t','y','x','v','a','average_a','xLow','xHigh','vLow','vHigh','aLow','aHigh'});
 writetable(Writetable,fullfile(out,[name '_ss_paths.csv']));allWindows=[allWindows;W]; %#ok<AGROW>
 audit=[audit;table(string(name),1999,E.pointEstimate.exitflag,delta,maxError,T(end),T(end-120), ...
  'VariableNames',{'Dataset','ValidDraws','PointExitFlag','MaxPointDifferenceFromLocalFit','MaxIntervalReconstructionError','EndTime','DecadeStart'})]; %#ok<AGROW>
 detail.(name)=E;
 fprintf('PASS %s: 1999 draws, matching data/source/options, max point difference %.3g, interval error %.3g.\n',name,delta,maxError);
end
writetable(audit,fullfile(out,'Audit.csv'));
writetable(allWindows,fullfile(out,'AverageAcceleration_Windows.csv'));
end
