function fit=v55_cached_fit(fun,input,o)
if ~isfolder(o.outputDir),mkdir(o.outputDir);end
file=fullfile(o.outputDir,'CompletedFit.mat');
key=struct('inputSHA',simulation_file_sha256(input),'options',o,'sourceSHA',simulation_file_sha256(which(func2str(fun))));
if isfile(file),L=load(file,'key','fit');assert(isequaln(key,L.key),'Cached specification changed.');fit=L.fit;return;end
started=tic;captured=evalc('fit=fun(input,o);');seconds=toc(started);
fid=fopen(fullfile(o.outputDir,'Estimation.log'),'w');fprintf(fid,'%s',captured);fclose(fid);
save(file,'key','fit','seconds','-v7.3');fprintf('%s: %.1f seconds\n',o.outputDir,seconds);
end
