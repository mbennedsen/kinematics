"""Audit and summarize the fixed NASA-path benchmark coverage experiment."""
from pathlib import Path
import sys
import hashlib
import json
import h5py
import numpy as np
import pandas as pd
from scipy.io import loadmat
from scipy.stats import binomtest

BASE=Path(__file__).resolve().parent
design=sys.argv[1];assert design in ['quadratic_truth','changepoint_truth']
method=design.removesuffix('_truth');selected=['quadratic','changepoint'].index(method)
ROOT=BASE/design
OUT=ROOT/'summary';OUT.mkdir(exist_ok=True)
manifest=BASE/'SHA256SUMS.tsv'
for line in manifest.read_text().splitlines():
    h,p=line.split('\t');assert hashlib.sha256((BASE/p).read_bytes()).hexdigest()==h,p
snapshot=hashlib.sha256(manifest.read_bytes()).hexdigest()
with h5py.File(BASE/'inputs/Calibration.mat') as f:
    P=f['C/parametric/'+method]
    b=np.asarray(P['coeff']).ravel();tref=float(np.asarray(P['tRef']).item())
    t=np.asarray(f['C/sample/t']).ravel();u=t-tref
    contribution=np.asarray(P['covariateContribution']).ravel()
    expected_path=np.zeros((len(t),3))
    if method=='quadratic':
        expected_path[:,0]=b[0]+b[1]*u+b[2]*u*u
        expected_path[:,1]=10*(b[1]+2*b[2]*u);expected_path[:,2]=200*b[2]
    else:
        tau=float(np.asarray(P['breakDate']).item());assert tau<2016.625
        expected_path[:,0]=b[0]+b[1]*u+b[2]*np.maximum(t-tau,0)
        expected_path[:,1]=10*(b[1]+b[2]*(t>=tau));expected_path[np.isclose(t,tau,rtol=0,atol=1e-9),2]=np.nan
path=pd.read_csv(ROOT/'FixedPath.csv')
np.testing.assert_allclose(path[['x','v','a']],expected_path,atol=1e-10,rtol=0)
T=path.t.iloc[-1];T0=T-10
assert abs(T-2026.625)<1e-9
i0=np.flatnonzero(np.isclose(path.t,T0,atol=1e-9,rtol=0));assert len(i0)==1
truth0=np.array([path.x.iloc[-1],path.v.iloc[-1],path.a.iloc[-1],
                 (path.v.iloc[-1]-path.v.iloc[i0[0]])/((T-T0)/10)])
methods=['quadratic','changepoint'];objects=['x_T','v_T','a_T','average_a_past_decade']
rows=[];present=[];retry=[];breaks=[];times=[];max_bound_error=0;max_outer_error=0
for f in sorted((ROOT/'results').glob('rep_*/Results.mat')):
    r=loadmat(f,simplify_cells=True)['R'];rep=int(f.parent.name[4:]);present.append(rep)
    assert r['snapshot']==snapshot and r['rep']==rep and r['B']==399
    assert hashlib.sha256((f.parent/'OuterSample.csv').read_bytes()).hexdigest()==r['inputSHA']
    expected=truth0.copy();expected[0]+=r['outerInfo']['rebaseShift']
    np.testing.assert_allclose(r['truth'],expected,atol=1e-9,rtol=0)
    raw=pd.read_csv(f.parent/'OuterSample.csv');ref=(raw.t>=1991)&(raw.t<2021)
    generated=expected_path[:,0]+contribution+r['outerInfo']['noise']
    err=np.max(np.abs(raw.NASA.dropna().to_numpy()-generated))
    assert err<1e-10
    max_outer_error=max(max_outer_error,err)
    assert abs(.88-raw.loc[ref,'NASA'].mean()-r['outerInfo']['rebaseShift'])<1e-10
    assert r['testedMethod']==selected+1
    if not r['success'][selected]:retry.append(rep)
    if r['success'][1]:
        d=r['draws'];assert d.shape==(399,4) and np.all(np.isfinite(d))
        assert r['referenceSearchChecks']==3
        q=np.percentile(d,[5,95],axis=0,method='hazen').T
        stored=np.column_stack((r['low'][1],r['high'][1]))
        err=np.max(np.abs(q[[0,1,3]]-stored[[0,1,3]]));max_bound_error=max(max_bound_error,err)
        assert err<1e-10
        assert np.isnan(stored[2]).all() and r['point'][1,2]==0 and np.all(d[:,2]==0)
        # Exact paired rate contrast, including the right-hand slope convention.
        computed=100*r['cpCoefficients'][2]*(np.asarray(r['breakDates'])>T0)/(T-T0)
        np.testing.assert_allclose(computed,d[:,3],atol=1e-10,rtol=0)
        assert np.all(np.isin(r['breakDates'],r['candidateBreakDates']))
        breaks.append(dict(Replication=rep,PointBreak=r['breakDate'],
                           BootstrapBreakAfterWindowStart=np.mean(r['breakDates']>T0),
                           AverageAccelerationIntervalZero=bool(np.all(stored[3]==0))))
    for m in [selected]:
        method=methods[m]
        ok=bool(r['success'][m]);times.append(dict(Replication=rep,Method=method,Seconds=r['seconds'][m]))
        for k,obj in enumerate(objects):
            truth=r['truth'][k];estimate=r['point'][m,k];lo=r['low'][m,k];hi=r['high'][m,k]
            interval=ok and np.isfinite(lo) and np.isfinite(hi)
            if interval:assert lo<=hi
            rows.append(dict(Replication=rep,Method=method,Estimand=obj,Success=ok,
                IntervalAvailable=interval,Truth=truth,Estimate=estimate,Low=lo,High=hi,
                Error=estimate-truth if ok else np.nan,
                Coverage=float(lo<=truth<=hi) if interval else np.nan,
                LowerAboveTruth=float(lo>truth) if interval else np.nan,
                UpperBelowTruth=float(hi<truth) if interval else np.nan,
                PositiveLower=float(lo>0) if interval else np.nan,
                Length=hi-lo if interval else np.nan,ValidDraws=r['validDraws'][m,k]))
R=pd.DataFrame(rows);R.to_csv(OUT/'Replications.csv',index=False)

def prop(vals):
    a=vals.dropna().to_numpy();n=len(a)
    if not n:return np.nan,np.nan,np.nan,np.nan
    p=np.mean(a);ci=binomtest(int(np.sum(a)),n).proportion_ci(method='wilson')
    return p,np.sqrt(p*(1-p)/n),ci.low,ci.high

summary=[]
for method in [methods[selected]]:
    for obj in objects:
        allrows=R[(R.Method==method)&(R.Estimand==obj)];z=allrows[allrows.Success]
        n=len(z);e=z.Error;length=z.Length.dropna()
        row=dict(Method=method,Estimand=obj,Planned=400,Returned=len(allrows),Valid=n,
                 Failed=len(allrows)-n,Intervals=int(z.IntervalAvailable.sum()),
                 MeanTruth=z.Truth.mean(),MeanEstimate=z.Estimate.mean(),Bias=e.mean(),
                 BiasMCSE=e.std(ddof=1)/np.sqrt(n) if n else np.nan,
                 RMSE=np.sqrt(np.mean(e**2)),MeanLength=length.mean(),
                 LengthMCSE=length.std(ddof=1)/np.sqrt(len(length)) if len(length) else np.nan)
        for col in ['Coverage','LowerAboveTruth','UpperBelowTruth','PositiveLower']:
            for suffix,value in zip(['','MCSE','WilsonLow','WilsonHigh'],prop(z[col])):row[col+suffix]=value
        summary.append(row)
S=pd.DataFrame(summary);S.to_csv(OUT/'Summary.csv',index=False)
pd.DataFrame(breaks).to_csv(OUT/'ChangepointDiagnostics.csv',index=False)
pd.DataFrame(times).to_csv(OUT/'Timing.csv',index=False)
missing=sorted(set(range(1,401))-set(present))
pd.DataFrame({'Replication':missing}).to_csv(OUT/'Missing.csv',index=False)
pd.DataFrame({'Replication':retry}).to_csv(OUT/'Retry.csv',index=False)
audit=dict(design=design,status='COMPLETE' if not missing and not retry else 'INCOMPLETE',planned=400,
           returned=len(present),missing=missing,retry=retry,snapshot=snapshot,
           intervalReconstructionMaxError=float(max_bound_error),
           outerObservationMaxError=float(max_outer_error),
           fixedDerivativeTruth=dict(zip(objects[1:],truth0[1:])),
           checks=['Frozen source and calibration hashes match',
                   'All synthetic input hashes match saved results',
                   'All outer observation equations independently reconstructed from frozen path, covariates and stored noise',
                   'Fitted parametric truth independently reconstructed from calibration coefficients',
                   'Rebased level truth and fixed derivative truths verified',
                   'All changepoint percentile bounds reconstruct from 399 draws',
                   'Paired past-decade contrasts and admissible breakpoint selections verified'])
(OUT/'Audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print(audit['status'],f'{len(present)}/400 returned; {len(retry)} retries')
print(S[['Method','Estimand','Valid','MeanTruth','MeanEstimate','Bias','Coverage',
         'LowerAboveTruth','UpperBelowTruth','PositiveLower','MeanLength']].to_string(index=False))
