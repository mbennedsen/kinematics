function [raw,truth,info]=v59_dgp3_outer(C,rep)
% Reuse the exact accuracy generator. Paper DGP 3 is legacy scenario 4.
d=C.selected(3);assert(d==4 && strcmp(C.scenarios{d},'NASA_smoothed'));
sim=simulate_four_estimator_dgp_v2(C,d,rep);
raw=C.raw;raw.NASA(:)=NaN;raw.NASA(C.sampleIndex)=sim.y;
truth=sim.truth;
info=struct('alpha',sim.alpha,'noise',sim.noise,'rebaseShift',0, ...
 'seed',C.cfg.seed+1000000+rep,'manuscriptDGP',3,'legacyDGP',d, ...
 'dgpMode','fixedIntegratedNASA_DGP3','averageStart',C.actualT0,'endTime',C.endTime);
end
