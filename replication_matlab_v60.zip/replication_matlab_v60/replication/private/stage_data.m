function stage_data(root,work)
% Give unchanged scientific engines their expected paths, from one data snapshot.
data=fullfile(root,'data');p=fullfile(work,'production');
emp=fullfile(p,'revision_v56_checks','cluster_uncertainty_hadisst');
folder=fullfile(emp,'Data');if ~isfolder(folder),mkdir(folder);end
for f={'Monthly_HadISST.csv','Annual_HadISST.csv','Annual_Baseline_Offsets.csv','Monthly_Smoothing_References.csv'}
 copyfile(fullfile(data,f{1}),fullfile(folder,f{1}));
end
copyfile(fullfile(data,'Configuration.mat'),fullfile(emp,'Configuration.mat'));
folder=fullfile(p,'revision_v55','cluster_empirical','Data');if ~isfolder(folder),mkdir(folder);end
copyfile(fullfile(data,'Monthly_NoCovariates.csv'),fullfile(folder,'ObservedData_no_covariates.csv'));
folder=fullfile(work,'simulations','inputs');if ~isfolder(folder),mkdir(folder);end
copyfile(fullfile(data,'Simulation','*'),folder);
end
